package android.support.v4.media;

import androidx.media.AudioAttributesImplApi26;
import androidx.media.AudioAttributesImplApi26Parcelizer;
import androidx.versionedparcelable.VersionedParcel;

public final class AudioAttributesImplApi26Parcelizer extends AudioAttributesImplApi26Parcelizer {
  public static AudioAttributesImplApi26 read(VersionedParcel paramVersionedParcel) {
    return AudioAttributesImplApi26Parcelizer.read(paramVersionedParcel);
  }
  
  public static void write(AudioAttributesImplApi26 paramAudioAttributesImplApi26, VersionedParcel paramVersionedParcel) {
    AudioAttributesImplApi26Parcelizer.write(paramAudioAttributesImplApi26, paramVersionedParcel);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\android\support\v4\media\AudioAttributesImplApi26Parcelizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */