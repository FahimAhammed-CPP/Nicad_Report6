package androidx.annotation;

import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import kotlin.Deprecated;
import kotlin.annotation.AnnotationRetention;
import kotlin.annotation.AnnotationTarget;
import kotlin.annotation.Retention;
import kotlin.annotation.Target;

@Retention(RetentionPolicy.SOURCE)
@Target({ElementType.METHOD})
@Deprecated(message = "Replaced by the {@code androidx.resourceinpsection} package.")
@Retention(AnnotationRetention.SOURCE)
@Target(allowedTargets = {AnnotationTarget.FUNCTION, AnnotationTarget.PROPERTY_GETTER, AnnotationTarget.PROPERTY_SETTER})
public @interface InspectableProperty {
  int attributeId() default 0;
  
  EnumEntry[] enumMapping() default {};
  
  FlagEntry[] flagMapping() default {};
  
  boolean hasAttributeId() default true;
  
  String name() default "";
  
  ValueType valueType() default ValueType.INFERRED;
  
  @Retention(RetentionPolicy.SOURCE)
  @Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE})
  @Retention(AnnotationRetention.SOURCE)
  @Target(allowedTargets = {AnnotationTarget.ANNOTATION_CLASS, AnnotationTarget.CLASS})
  public static @interface EnumEntry {
    String name();
    
    int value();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @Target({ElementType.TYPE, ElementType.ANNOTATION_TYPE})
  @Retention(AnnotationRetention.SOURCE)
  @Target(allowedTargets = {AnnotationTarget.ANNOTATION_CLASS, AnnotationTarget.CLASS})
  public static @interface FlagEntry {
    int mask() default 0;
    
    String name();
    
    int target();
  }
  
  public enum ValueType {
    COLOR, GRAVITY, INFERRED, INT_ENUM, INT_FLAG, NONE, RESOURCE_ID;
    
    static {
      COLOR = new ValueType(v416f9e89.xbd520268("758"), 4);
      GRAVITY = new ValueType(v416f9e89.xbd520268("759"), 5);
      RESOURCE_ID = new ValueType(v416f9e89.xbd520268("760"), 6);
      $VALUES = $values();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\annotation\InspectableProperty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */