package androidx.appcompat.widget;

import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import androidx.core.view.ViewCompat;
import h8800e55c.pc41fcc5f.v416f9e89;
import h8800e55c.x78d2f21c.y0bc38925;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ViewUtils {
  private static final String TAG = v416f9e89.xbd520268("1180");
  
  private static Method sComputeFitSystemWindowsMethod;
  
  static {
    if (Build.VERSION.SDK_INT >= 18)
      try {
        Method method = y0bc38925.g0dcf584d(View.class, v416f9e89.xbd520268("1181"), new Class[] { Rect.class, Rect.class });
        sComputeFitSystemWindowsMethod = method;
        if (!method.isAccessible()) {
          sComputeFitSystemWindowsMethod.setAccessible(true);
          return;
        } 
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.d(v416f9e89.xbd520268("1182"), v416f9e89.xbd520268("1183"));
      }  
  }
  
  public static void computeFitSystemWindows(View paramView, Rect paramRect1, Rect paramRect2) {
    Method method = sComputeFitSystemWindowsMethod;
    if (method != null)
      try {
        method.invoke(paramView, new Object[] { paramRect1, paramRect2 });
        return;
      } catch (Exception exception) {
        Log.d(v416f9e89.xbd520268("1184"), v416f9e89.xbd520268("1185"), exception);
      }  
  }
  
  public static boolean isLayoutRtl(View paramView) {
    return (ViewCompat.getLayoutDirection(paramView) == 1);
  }
  
  public static void makeOptionalFitsSystemWindows(View paramView) {
    String str2 = v416f9e89.xbd520268("1186");
    String str1 = v416f9e89.xbd520268("1187");
    if (Build.VERSION.SDK_INT >= 16)
      try {
        Method method = y0bc38925.getMethod(paramView.getClass(), v416f9e89.xbd520268("1188"), new Class[0]);
        if (!method.isAccessible())
          method.setAccessible(true); 
        method.invoke(paramView, new Object[0]);
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.d(str1, v416f9e89.xbd520268("1189"));
      } catch (InvocationTargetException invocationTargetException) {
        Log.d(str1, str2, invocationTargetException);
        return;
      } catch (IllegalAccessException illegalAccessException) {
        Log.d(str1, str2, illegalAccessException);
        return;
      }  
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\appcompat\widget\ViewUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */