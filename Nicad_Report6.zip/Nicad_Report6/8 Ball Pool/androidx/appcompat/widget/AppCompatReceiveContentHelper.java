package androidx.appcompat.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Selection;
import android.text.Spannable;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.view.inputmethod.InputContentInfo;
import android.widget.TextView;
import androidx.core.view.ContentInfoCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.inputmethod.InputConnectionCompat;
import androidx.core.view.inputmethod.InputContentInfoCompat;
import h8800e55c.pc41fcc5f.v416f9e89;

final class AppCompatReceiveContentHelper {
  private static final String EXTRA_INPUT_CONTENT_INFO = v416f9e89.xbd520268("1172");
  
  private static final String LOG_TAG = v416f9e89.xbd520268("1173");
  
  static InputConnectionCompat.OnCommitContentListener createOnCommitContentListener(final View view) {
    return new InputConnectionCompat.OnCommitContentListener() {
        public boolean onCommitContent(InputContentInfoCompat param1InputContentInfoCompat, int param1Int, Bundle param1Bundle) {
          int i = Build.VERSION.SDK_INT;
          boolean bool = false;
          Bundle bundle = param1Bundle;
          if (i >= 25) {
            bundle = param1Bundle;
            if ((param1Int & 0x1) != 0)
              try {
                param1InputContentInfoCompat.requestPermission();
                InputContentInfo inputContentInfo = (InputContentInfo)param1InputContentInfoCompat.unwrap();
                if (param1Bundle == null) {
                  param1Bundle = new Bundle();
                } else {
                  param1Bundle = new Bundle(param1Bundle);
                } 
                param1Bundle.putParcelable(v416f9e89.xbd520268("1169"), (Parcelable)inputContentInfo);
                bundle = param1Bundle;
              } catch (Exception exception) {
                Log.w(v416f9e89.xbd520268("1170"), v416f9e89.xbd520268("1171"), exception);
                return false;
              }  
          } 
          ContentInfoCompat contentInfoCompat = (new ContentInfoCompat.Builder(new ClipData(exception.getDescription(), new ClipData.Item(exception.getContentUri())), 2)).setLinkUri(exception.getLinkUri()).setExtras(bundle).build();
          if (ViewCompat.performReceiveContent(view, contentInfoCompat) == null)
            bool = true; 
          return bool;
        }
      };
  }
  
  static boolean maybeHandleDragEventViaPerformReceiveContent(View paramView, DragEvent paramDragEvent) {
    if (Build.VERSION.SDK_INT >= 24 && paramDragEvent.getLocalState() == null) {
      String str;
      StringBuilder stringBuilder;
      if (ViewCompat.getOnReceiveContentMimeTypes(paramView) == null)
        return false; 
      Activity activity = tryGetActivity(paramView);
      if (activity == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("1174"));
        stringBuilder.append(paramView);
        str = stringBuilder.toString();
        Log.i(v416f9e89.xbd520268("1175"), str);
        return false;
      } 
      if (stringBuilder.getAction() == 1)
        return str instanceof TextView ^ true; 
      if (stringBuilder.getAction() == 3)
        return (str instanceof TextView) ? OnDropApi24Impl.onDropForTextView((DragEvent)stringBuilder, (TextView)str, activity) : OnDropApi24Impl.onDropForView((DragEvent)stringBuilder, (View)str, activity); 
    } 
    return false;
  }
  
  static boolean maybeHandleMenuActionViaPerformReceiveContent(TextView paramTextView, int paramInt) {
    ClipData clipData;
    boolean bool = false;
    if ((paramInt != 16908322 && paramInt != 16908337) || ViewCompat.getOnReceiveContentMimeTypes((View)paramTextView) == null)
      return false; 
    ClipboardManager clipboardManager = (ClipboardManager)paramTextView.getContext().getSystemService(v416f9e89.xbd520268("1176"));
    if (clipboardManager == null) {
      clipboardManager = null;
    } else {
      clipData = clipboardManager.getPrimaryClip();
    } 
    if (clipData != null && clipData.getItemCount() > 0) {
      ContentInfoCompat.Builder builder = new ContentInfoCompat.Builder(clipData, 1);
      if (paramInt == 16908322) {
        paramInt = bool;
      } else {
        paramInt = 1;
      } 
      ViewCompat.performReceiveContent((View)paramTextView, builder.setFlags(paramInt).build());
    } 
    return true;
  }
  
  static Activity tryGetActivity(View paramView) {
    for (Context context = paramView.getContext(); context instanceof ContextWrapper; context = ((ContextWrapper)context).getBaseContext()) {
      if (context instanceof Activity)
        return (Activity)context; 
    } 
    return null;
  }
  
  private static final class OnDropApi24Impl {
    static boolean onDropForTextView(DragEvent param1DragEvent, TextView param1TextView, Activity param1Activity) {
      param1Activity.requestDragAndDropPermissions(param1DragEvent);
      int i = param1TextView.getOffsetForPosition(param1DragEvent.getX(), param1DragEvent.getY());
      param1TextView.beginBatchEdit();
      try {
        Selection.setSelection((Spannable)param1TextView.getText(), i);
        ViewCompat.performReceiveContent((View)param1TextView, (new ContentInfoCompat.Builder(param1DragEvent.getClipData(), 3)).build());
        return true;
      } finally {
        param1TextView.endBatchEdit();
      } 
    }
    
    static boolean onDropForView(DragEvent param1DragEvent, View param1View, Activity param1Activity) {
      param1Activity.requestDragAndDropPermissions(param1DragEvent);
      ViewCompat.performReceiveContent(param1View, (new ContentInfoCompat.Builder(param1DragEvent.getClipData(), 3)).build());
      return true;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\appcompat\widget\AppCompatReceiveContentHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */