package androidx.activity;

public final class R {
  public static final class attr {
    public static final int alpha = 2130968664;
    
    public static final int font = 2130969054;
    
    public static final int fontProviderAuthority = 2130969056;
    
    public static final int fontProviderCerts = 2130969057;
    
    public static final int fontProviderFetchStrategy = 2130969058;
    
    public static final int fontProviderFetchTimeout = 2130969059;
    
    public static final int fontProviderPackage = 2130969060;
    
    public static final int fontProviderQuery = 2130969061;
    
    public static final int fontStyle = 2130969063;
    
    public static final int fontVariationSettings = 2130969064;
    
    public static final int fontWeight = 2130969065;
    
    public static final int ttcIndex = 2130969644;
  }
  
  public static final class color {
    public static final int notification_action_color_filter = 2131100386;
    
    public static final int notification_icon_bg_color = 2131100387;
    
    public static final int ripple_material_light = 2131100399;
    
    public static final int secondary_text_default_material_light = 2131100402;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131165353;
    
    public static final int compat_button_inset_vertical_material = 2131165354;
    
    public static final int compat_button_padding_horizontal_material = 2131165355;
    
    public static final int compat_button_padding_vertical_material = 2131165356;
    
    public static final int compat_control_corner_material = 2131165357;
    
    public static final int compat_notification_large_icon_max_height = 2131165358;
    
    public static final int compat_notification_large_icon_max_width = 2131165359;
    
    public static final int notification_action_icon_size = 2131165903;
    
    public static final int notification_action_text_size = 2131165904;
    
    public static final int notification_big_circle_margin = 2131165905;
    
    public static final int notification_content_margin_start = 2131165906;
    
    public static final int notification_large_icon_height = 2131165907;
    
    public static final int notification_large_icon_width = 2131165908;
    
    public static final int notification_main_column_padding_top = 2131165909;
    
    public static final int notification_media_narrow_margin = 2131165910;
    
    public static final int notification_right_icon_size = 2131165915;
    
    public static final int notification_right_side_padding_top = 2131165916;
    
    public static final int notification_small_icon_background_padding = 2131165918;
    
    public static final int notification_small_icon_size_as_large = 2131165919;
    
    public static final int notification_subtext_size = 2131165920;
    
    public static final int notification_top_pad = 2131165921;
    
    public static final int notification_top_pad_large_text = 2131165922;
  }
  
  public static final class drawable {
    public static final int notification_action_background = 2131231254;
    
    public static final int notification_bg = 2131231256;
    
    public static final int notification_bg_low = 2131231257;
    
    public static final int notification_bg_low_normal = 2131231258;
    
    public static final int notification_bg_low_pressed = 2131231259;
    
    public static final int notification_bg_normal = 2131231260;
    
    public static final int notification_bg_normal_pressed = 2131231261;
    
    public static final int notification_icon_background = 2131231262;
    
    public static final int notification_template_icon_bg = 2131231263;
    
    public static final int notification_template_icon_low_bg = 2131231264;
    
    public static final int notification_tile_bg = 2131231265;
    
    public static final int notify_panel_notification_icon_bg = 2131231266;
  }
  
  public static final class id {
    public static final int accessibility_action_clickable_span = 2131361813;
    
    public static final int accessibility_custom_action_0 = 2131361814;
    
    public static final int accessibility_custom_action_1 = 2131361815;
    
    public static final int accessibility_custom_action_10 = 2131361816;
    
    public static final int accessibility_custom_action_11 = 2131361817;
    
    public static final int accessibility_custom_action_12 = 2131361818;
    
    public static final int accessibility_custom_action_13 = 2131361819;
    
    public static final int accessibility_custom_action_14 = 2131361820;
    
    public static final int accessibility_custom_action_15 = 2131361821;
    
    public static final int accessibility_custom_action_16 = 2131361822;
    
    public static final int accessibility_custom_action_17 = 2131361823;
    
    public static final int accessibility_custom_action_18 = 2131361824;
    
    public static final int accessibility_custom_action_19 = 2131361825;
    
    public static final int accessibility_custom_action_2 = 2131361826;
    
    public static final int accessibility_custom_action_20 = 2131361827;
    
    public static final int accessibility_custom_action_21 = 2131361828;
    
    public static final int accessibility_custom_action_22 = 2131361829;
    
    public static final int accessibility_custom_action_23 = 2131361830;
    
    public static final int accessibility_custom_action_24 = 2131361831;
    
    public static final int accessibility_custom_action_25 = 2131361832;
    
    public static final int accessibility_custom_action_26 = 2131361833;
    
    public static final int accessibility_custom_action_27 = 2131361834;
    
    public static final int accessibility_custom_action_28 = 2131361835;
    
    public static final int accessibility_custom_action_29 = 2131361836;
    
    public static final int accessibility_custom_action_3 = 2131361837;
    
    public static final int accessibility_custom_action_30 = 2131361838;
    
    public static final int accessibility_custom_action_31 = 2131361839;
    
    public static final int accessibility_custom_action_4 = 2131361840;
    
    public static final int accessibility_custom_action_5 = 2131361841;
    
    public static final int accessibility_custom_action_6 = 2131361842;
    
    public static final int accessibility_custom_action_7 = 2131361843;
    
    public static final int accessibility_custom_action_8 = 2131361844;
    
    public static final int accessibility_custom_action_9 = 2131361845;
    
    public static final int action_container = 2131361854;
    
    public static final int action_divider = 2131361856;
    
    public static final int action_image = 2131361857;
    
    public static final int action_text = 2131361864;
    
    public static final int actions = 2131361865;
    
    public static final int async = 2131361967;
    
    public static final int blocking = 2131361983;
    
    public static final int chronometer = 2131362013;
    
    public static final int dialog_button = 2131362064;
    
    public static final int forever = 2131362118;
    
    public static final int icon = 2131362168;
    
    public static final int icon_group = 2131362169;
    
    public static final int info = 2131362177;
    
    public static final int italic = 2131362194;
    
    public static final int line1 = 2131362207;
    
    public static final int line3 = 2131362208;
    
    public static final int normal = 2131362441;
    
    public static final int notification_background = 2131362442;
    
    public static final int notification_main_column = 2131362443;
    
    public static final int notification_main_column_container = 2131362444;
    
    public static final int right_icon = 2131362507;
    
    public static final int right_side = 2131362508;
    
    public static final int tag_accessibility_actions = 2131362588;
    
    public static final int tag_accessibility_clickable_spans = 2131362589;
    
    public static final int tag_accessibility_heading = 2131362590;
    
    public static final int tag_accessibility_pane_title = 2131362591;
    
    public static final int tag_screen_reader_focusable = 2131362595;
    
    public static final int tag_transition_group = 2131362597;
    
    public static final int tag_unhandled_key_event_manager = 2131362598;
    
    public static final int tag_unhandled_key_listeners = 2131362599;
    
    public static final int text = 2131362605;
    
    public static final int text2 = 2131362606;
    
    public static final int time = 2131362624;
    
    public static final int title = 2131362628;
    
    public static final int view_tree_lifecycle_owner = 2131362662;
    
    public static final int view_tree_saved_state_registry_owner = 2131362663;
    
    public static final int view_tree_view_model_store_owner = 2131362664;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131427388;
  }
  
  public static final class layout {
    public static final int custom_dialog = 2131558467;
    
    public static final int notification_action = 2131558606;
    
    public static final int notification_action_tombstone = 2131558607;
    
    public static final int notification_template_custom_big = 2131558614;
    
    public static final int notification_template_icon_group = 2131558615;
    
    public static final int notification_template_part_chronometer = 2131558619;
    
    public static final int notification_template_part_time = 2131558620;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131886667;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131952106;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131952107;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131952109;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131952112;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131952114;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131952439;
    
    public static final int Widget_Compat_NotificationActionText = 2131952440;
  }
  
  public static final class styleable {
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 16844359, 2130968664, 2130969154 };
    
    public static final int ColorStateListItem_alpha = 3;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int ColorStateListItem_android_lStar = 2;
    
    public static final int ColorStateListItem_lStar = 4;
    
    public static final int[] FontFamily = new int[] { 2130969056, 2130969057, 2130969058, 2130969059, 2130969060, 2130969061, 2130969062 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130969054, 2130969063, 2130969064, 2130969065, 2130969644 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int FontFamily_fontProviderSystemFontFamily = 6;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\activity\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */