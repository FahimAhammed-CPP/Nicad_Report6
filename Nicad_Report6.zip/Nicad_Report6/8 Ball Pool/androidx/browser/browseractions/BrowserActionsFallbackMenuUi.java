package androidx.browser.browseractions;

import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.browser.R;
import androidx.core.widget.TextViewCompat;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;
import java.util.List;

@Deprecated
class BrowserActionsFallbackMenuUi implements AdapterView.OnItemClickListener {
  private static final String TAG = v416f9e89.xbd520268("1371");
  
  private BrowserActionsFallbackMenuDialog mBrowserActionsDialog;
  
  final Context mContext;
  
  private final List<BrowserActionItem> mMenuItems;
  
  BrowserActionsFallMenuUiListener mMenuUiListener;
  
  final Uri mUri;
  
  BrowserActionsFallbackMenuUi(Context paramContext, Uri paramUri, List<BrowserActionItem> paramList) {
    this.mContext = paramContext;
    this.mUri = paramUri;
    this.mMenuItems = buildFallbackMenuItemList(paramList);
  }
  
  private Runnable buildCopyAction() {
    return new Runnable() {
        public void run() {
          ClipboardManager clipboardManager = (ClipboardManager)BrowserActionsFallbackMenuUi.this.mContext.getSystemService(v416f9e89.xbd520268("1367"));
          String str2 = BrowserActionsFallbackMenuUi.this.mUri.toString();
          clipboardManager.setPrimaryClip(ClipData.newPlainText(v416f9e89.xbd520268("1368"), str2));
          String str1 = BrowserActionsFallbackMenuUi.this.mContext.getString(R.string.copy_toast_msg);
          Toast.makeText(BrowserActionsFallbackMenuUi.this.mContext, str1, 0).show();
        }
      };
  }
  
  private List<BrowserActionItem> buildFallbackMenuItemList(List<BrowserActionItem> paramList) {
    ArrayList<BrowserActionItem> arrayList = new ArrayList();
    arrayList.add(new BrowserActionItem(this.mContext.getString(R.string.fallback_menu_item_open_in_browser), buildOpenInBrowserAction()));
    arrayList.add(new BrowserActionItem(this.mContext.getString(R.string.fallback_menu_item_copy_link), buildCopyAction()));
    arrayList.add(new BrowserActionItem(this.mContext.getString(R.string.fallback_menu_item_share_link), buildShareAction()));
    arrayList.addAll(paramList);
    return arrayList;
  }
  
  private PendingIntent buildOpenInBrowserAction() {
    Uri uri = this.mUri;
    Intent intent = new Intent(v416f9e89.xbd520268("1372"), uri);
    return PendingIntent.getActivity(this.mContext, 0, intent, 67108864);
  }
  
  private PendingIntent buildShareAction() {
    Intent intent = new Intent(v416f9e89.xbd520268("1373"));
    String str = this.mUri.toString();
    intent.putExtra(v416f9e89.xbd520268("1374"), str);
    intent.setType(v416f9e89.xbd520268("1375"));
    return PendingIntent.getActivity(this.mContext, 0, intent, 67108864);
  }
  
  private BrowserActionsFallbackMenuView initMenuView(View paramView) {
    BrowserActionsFallbackMenuView browserActionsFallbackMenuView = (BrowserActionsFallbackMenuView)paramView.findViewById(R.id.browser_actions_menu_view);
    final TextView urlTextView = (TextView)paramView.findViewById(R.id.browser_actions_header_text);
    textView.setText(this.mUri.toString());
    textView.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (TextViewCompat.getMaxLines(urlTextView) == Integer.MAX_VALUE) {
              urlTextView.setMaxLines(1);
              urlTextView.setEllipsize(TextUtils.TruncateAt.END);
              return;
            } 
            urlTextView.setMaxLines(2147483647);
            urlTextView.setEllipsize(null);
          }
        });
    ListView listView = (ListView)paramView.findViewById(R.id.browser_actions_menu_items);
    listView.setAdapter((ListAdapter)new BrowserActionsFallbackMenuAdapter(this.mMenuItems, this.mContext));
    listView.setOnItemClickListener(this);
    return browserActionsFallbackMenuView;
  }
  
  public void displayMenu() {
    final View view = LayoutInflater.from(this.mContext).inflate(R.layout.browser_actions_context_menu_page, null);
    BrowserActionsFallbackMenuDialog browserActionsFallbackMenuDialog = new BrowserActionsFallbackMenuDialog(this.mContext, (View)initMenuView(view));
    this.mBrowserActionsDialog = browserActionsFallbackMenuDialog;
    browserActionsFallbackMenuDialog.setContentView(view);
    if (this.mMenuUiListener != null)
      this.mBrowserActionsDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            public void onShow(DialogInterface param1DialogInterface) {
              if (BrowserActionsFallbackMenuUi.this.mMenuUiListener == null) {
                Log.e(v416f9e89.xbd520268("1369"), v416f9e89.xbd520268("1370"));
                return;
              } 
              BrowserActionsFallbackMenuUi.this.mMenuUiListener.onMenuShown(view);
            }
          }); 
    this.mBrowserActionsDialog.show();
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    BrowserActionItem browserActionItem = this.mMenuItems.get(paramInt);
    PendingIntent pendingIntent = browserActionItem.getAction();
    String str = v416f9e89.xbd520268("1376");
    if (pendingIntent != null) {
      try {
        browserActionItem.getAction().send();
      } catch (android.app.PendingIntent.CanceledException canceledException) {
        Log.e(str, v416f9e89.xbd520268("1377"), (Throwable)canceledException);
      } 
    } else if (canceledException.getRunnableAction() != null) {
      canceledException.getRunnableAction().run();
    } 
    BrowserActionsFallbackMenuDialog browserActionsFallbackMenuDialog = this.mBrowserActionsDialog;
    if (browserActionsFallbackMenuDialog == null) {
      Log.e(str, v416f9e89.xbd520268("1378"));
      return;
    } 
    browserActionsFallbackMenuDialog.dismiss();
  }
  
  void setMenuUiListener(BrowserActionsFallMenuUiListener paramBrowserActionsFallMenuUiListener) {
    this.mMenuUiListener = paramBrowserActionsFallMenuUiListener;
  }
  
  static interface BrowserActionsFallMenuUiListener {
    void onMenuShown(View param1View);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\browseractions\BrowserActionsFallbackMenuUi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */