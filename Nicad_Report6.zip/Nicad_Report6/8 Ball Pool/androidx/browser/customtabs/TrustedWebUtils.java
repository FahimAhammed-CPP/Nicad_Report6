package androidx.browser.customtabs;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import androidx.core.app.BundleCompat;
import androidx.core.content.FileProvider;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.io.File;

public class TrustedWebUtils {
  public static final String ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA = v416f9e89.xbd520268("1756");
  
  public static final String EXTRA_LAUNCH_AS_TRUSTED_WEB_ACTIVITY = v416f9e89.xbd520268("1757");
  
  public static boolean areSplashScreensSupported(Context paramContext, String paramString1, String paramString2) {
    Intent intent = (new Intent()).setAction(v416f9e89.xbd520268("1758")).setPackage(paramString1);
    ResolveInfo resolveInfo = paramContext.getPackageManager().resolveService(intent, 64);
    return (resolveInfo == null || resolveInfo.filter == null) ? false : resolveInfo.filter.hasCategory(paramString2);
  }
  
  @Deprecated
  public static void launchAsTrustedWebActivity(Context paramContext, CustomTabsIntent paramCustomTabsIntent, Uri paramUri) {
    if (BundleCompat.getBinder(paramCustomTabsIntent.intent.getExtras(), v416f9e89.xbd520268("1759")) != null) {
      paramCustomTabsIntent.intent.putExtra(v416f9e89.xbd520268("1760"), true);
      paramCustomTabsIntent.launchUrl(paramContext, paramUri);
      return;
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("1761"));
  }
  
  public static void launchBrowserSiteSettings(Context paramContext, CustomTabsSession paramCustomTabsSession, Uri paramUri) {
    Intent intent = new Intent(v416f9e89.xbd520268("1762"));
    intent.setPackage(paramCustomTabsSession.getComponentName().getPackageName());
    intent.setData(paramUri);
    Bundle bundle = new Bundle();
    IBinder iBinder = paramCustomTabsSession.getBinder();
    BundleCompat.putBinder(bundle, v416f9e89.xbd520268("1763"), iBinder);
    intent.putExtras(bundle);
    PendingIntent pendingIntent = paramCustomTabsSession.getId();
    if (pendingIntent != null)
      intent.putExtra(v416f9e89.xbd520268("1764"), (Parcelable)pendingIntent); 
    paramContext.startActivity(intent);
  }
  
  public static boolean transferSplashImage(Context paramContext, File paramFile, String paramString1, String paramString2, CustomTabsSession paramCustomTabsSession) {
    Uri uri = FileProvider.getUriForFile(paramContext, paramString1, paramFile);
    paramContext.grantUriPermission(paramString2, uri, 1);
    return paramCustomTabsSession.receiveFile(uri, 1, null);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\customtabs\TrustedWebUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */