package androidx.browser.trusted;

import android.app.Notification;
import android.content.ComponentName;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.customtabs.trusted.ITrustedWebActivityCallback;
import android.support.customtabs.trusted.ITrustedWebActivityService;
import h8800e55c.pc41fcc5f.v416f9e89;

public final class TrustedWebActivityServiceConnection {
  private static final String KEY_ACTIVE_NOTIFICATIONS = v416f9e89.xbd520268("1532");
  
  private static final String KEY_CHANNEL_NAME = v416f9e89.xbd520268("1533");
  
  private static final String KEY_NOTIFICATION = v416f9e89.xbd520268("1534");
  
  private static final String KEY_NOTIFICATION_SUCCESS = v416f9e89.xbd520268("1535");
  
  private static final String KEY_PLATFORM_ID = v416f9e89.xbd520268("1536");
  
  private static final String KEY_PLATFORM_TAG = v416f9e89.xbd520268("1537");
  
  private final ComponentName mComponentName;
  
  private final ITrustedWebActivityService mService;
  
  TrustedWebActivityServiceConnection(ITrustedWebActivityService paramITrustedWebActivityService, ComponentName paramComponentName) {
    this.mService = paramITrustedWebActivityService;
    this.mComponentName = paramComponentName;
  }
  
  static void ensureBundleContains(Bundle paramBundle, String paramString) {
    if (paramBundle.containsKey(paramString))
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("1538"));
    stringBuilder.append(paramString);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static ITrustedWebActivityCallback wrapCallback(final TrustedWebActivityCallback callback) {
    return (ITrustedWebActivityCallback)((callback == null) ? null : new ITrustedWebActivityCallback.Stub() {
        public void onExtraCallback(String param1String, Bundle param1Bundle) throws RemoteException {
          callback.onExtraCallback(param1String, param1Bundle);
        }
      });
  }
  
  public boolean areNotificationsEnabled(String paramString) throws RemoteException {
    Bundle bundle = (new NotificationsEnabledArgs(paramString)).toBundle();
    return (ResultArgs.fromBundle(this.mService.areNotificationsEnabled(bundle))).success;
  }
  
  public void cancel(String paramString, int paramInt) throws RemoteException {
    Bundle bundle = (new CancelNotificationArgs(paramString, paramInt)).toBundle();
    this.mService.cancelNotification(bundle);
  }
  
  public Parcelable[] getActiveNotifications() throws RemoteException {
    return (ActiveNotificationsArgs.fromBundle(this.mService.getActiveNotifications())).notifications;
  }
  
  public ComponentName getComponentName() {
    return this.mComponentName;
  }
  
  public Bitmap getSmallIconBitmap() throws RemoteException {
    return (Bitmap)this.mService.getSmallIconBitmap().getParcelable(v416f9e89.xbd520268("1539"));
  }
  
  public int getSmallIconId() throws RemoteException {
    return this.mService.getSmallIconId();
  }
  
  public boolean notify(String paramString1, int paramInt, Notification paramNotification, String paramString2) throws RemoteException {
    Bundle bundle = (new NotifyNotificationArgs(paramString1, paramInt, paramNotification, paramString2)).toBundle();
    return (ResultArgs.fromBundle(this.mService.notifyNotificationWithChannel(bundle))).success;
  }
  
  public Bundle sendExtraCommand(String paramString, Bundle paramBundle, TrustedWebActivityCallback paramTrustedWebActivityCallback) throws RemoteException {
    IBinder iBinder;
    ITrustedWebActivityCallback iTrustedWebActivityCallback = wrapCallback(paramTrustedWebActivityCallback);
    if (iTrustedWebActivityCallback == null) {
      iTrustedWebActivityCallback = null;
    } else {
      iBinder = iTrustedWebActivityCallback.asBinder();
    } 
    return this.mService.extraCommand(paramString, paramBundle, iBinder);
  }
  
  static class ActiveNotificationsArgs {
    public final Parcelable[] notifications;
    
    ActiveNotificationsArgs(Parcelable[] param1ArrayOfParcelable) {
      this.notifications = param1ArrayOfParcelable;
    }
    
    public static ActiveNotificationsArgs fromBundle(Bundle param1Bundle) {
      String str = v416f9e89.xbd520268("1505");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str);
      return new ActiveNotificationsArgs(param1Bundle.getParcelableArray(str));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      Parcelable[] arrayOfParcelable = this.notifications;
      bundle.putParcelableArray(v416f9e89.xbd520268("1506"), arrayOfParcelable);
      return bundle;
    }
  }
  
  static class CancelNotificationArgs {
    public final int platformId;
    
    public final String platformTag;
    
    CancelNotificationArgs(String param1String, int param1Int) {
      this.platformTag = param1String;
      this.platformId = param1Int;
    }
    
    public static CancelNotificationArgs fromBundle(Bundle param1Bundle) {
      String str1 = v416f9e89.xbd520268("1507");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str1);
      String str2 = v416f9e89.xbd520268("1508");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str2);
      return new CancelNotificationArgs(param1Bundle.getString(str1), param1Bundle.getInt(str2));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      String str = this.platformTag;
      bundle.putString(v416f9e89.xbd520268("1509"), str);
      int i = this.platformId;
      bundle.putInt(v416f9e89.xbd520268("1510"), i);
      return bundle;
    }
  }
  
  static class NotificationsEnabledArgs {
    public final String channelName;
    
    NotificationsEnabledArgs(String param1String) {
      this.channelName = param1String;
    }
    
    public static NotificationsEnabledArgs fromBundle(Bundle param1Bundle) {
      String str = v416f9e89.xbd520268("1520");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str);
      return new NotificationsEnabledArgs(param1Bundle.getString(str));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      String str = this.channelName;
      bundle.putString(v416f9e89.xbd520268("1521"), str);
      return bundle;
    }
  }
  
  static class NotifyNotificationArgs {
    public final String channelName;
    
    public final Notification notification;
    
    public final int platformId;
    
    public final String platformTag;
    
    NotifyNotificationArgs(String param1String1, int param1Int, Notification param1Notification, String param1String2) {
      this.platformTag = param1String1;
      this.platformId = param1Int;
      this.notification = param1Notification;
      this.channelName = param1String2;
    }
    
    public static NotifyNotificationArgs fromBundle(Bundle param1Bundle) {
      String str1 = v416f9e89.xbd520268("1522");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str1);
      String str2 = v416f9e89.xbd520268("1523");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str2);
      String str3 = v416f9e89.xbd520268("1524");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str3);
      String str4 = v416f9e89.xbd520268("1525");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str4);
      return new NotifyNotificationArgs(param1Bundle.getString(str1), param1Bundle.getInt(str2), (Notification)param1Bundle.getParcelable(str3), param1Bundle.getString(str4));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      String str2 = this.platformTag;
      bundle.putString(v416f9e89.xbd520268("1526"), str2);
      int i = this.platformId;
      bundle.putInt(v416f9e89.xbd520268("1527"), i);
      Notification notification = this.notification;
      bundle.putParcelable(v416f9e89.xbd520268("1528"), (Parcelable)notification);
      String str1 = this.channelName;
      bundle.putString(v416f9e89.xbd520268("1529"), str1);
      return bundle;
    }
  }
  
  static class ResultArgs {
    public final boolean success;
    
    ResultArgs(boolean param1Boolean) {
      this.success = param1Boolean;
    }
    
    public static ResultArgs fromBundle(Bundle param1Bundle) {
      String str = v416f9e89.xbd520268("1530");
      TrustedWebActivityServiceConnection.ensureBundleContains(param1Bundle, str);
      return new ResultArgs(param1Bundle.getBoolean(str));
    }
    
    public Bundle toBundle() {
      Bundle bundle = new Bundle();
      boolean bool = this.success;
      bundle.putBoolean(v416f9e89.xbd520268("1531"), bool);
      return bundle;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\trusted\TrustedWebActivityServiceConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */