package androidx.browser.trusted;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.browser.customtabs.CustomTabsSession;
import androidx.browser.trusted.sharing.ShareData;
import androidx.browser.trusted.sharing.ShareTarget;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class TrustedWebActivityIntentBuilder {
  public static final String EXTRA_ADDITIONAL_TRUSTED_ORIGINS = v416f9e89.xbd520268("1471");
  
  public static final String EXTRA_DISPLAY_MODE = v416f9e89.xbd520268("1472");
  
  public static final String EXTRA_SCREEN_ORIENTATION = v416f9e89.xbd520268("1473");
  
  public static final String EXTRA_SHARE_DATA = v416f9e89.xbd520268("1474");
  
  public static final String EXTRA_SHARE_TARGET = v416f9e89.xbd520268("1475");
  
  public static final String EXTRA_SPLASH_SCREEN_PARAMS = v416f9e89.xbd520268("1476");
  
  private List<String> mAdditionalTrustedOrigins;
  
  private TrustedWebActivityDisplayMode mDisplayMode = new TrustedWebActivityDisplayMode.DefaultMode();
  
  private final CustomTabsIntent.Builder mIntentBuilder = new CustomTabsIntent.Builder();
  
  private int mScreenOrientation = 0;
  
  private ShareData mShareData;
  
  private ShareTarget mShareTarget;
  
  private Bundle mSplashScreenParams;
  
  private final Uri mUri;
  
  public TrustedWebActivityIntentBuilder(Uri paramUri) {
    this.mUri = paramUri;
  }
  
  public TrustedWebActivityIntent build(CustomTabsSession paramCustomTabsSession) {
    Objects.requireNonNull(paramCustomTabsSession, v416f9e89.xbd520268("1477"));
    this.mIntentBuilder.setSession(paramCustomTabsSession);
    Intent intent = (this.mIntentBuilder.build()).intent;
    intent.setData(this.mUri);
    intent.putExtra(v416f9e89.xbd520268("1478"), true);
    if (this.mAdditionalTrustedOrigins != null) {
      ArrayList<String> arrayList = new ArrayList<String>(this.mAdditionalTrustedOrigins);
      intent.putExtra(v416f9e89.xbd520268("1479"), arrayList);
    } 
    Bundle bundle1 = this.mSplashScreenParams;
    if (bundle1 != null)
      intent.putExtra(v416f9e89.xbd520268("1480"), bundle1); 
    List<?> list2 = Collections.emptyList();
    ShareTarget shareTarget = this.mShareTarget;
    List<?> list1 = list2;
    if (shareTarget != null) {
      list1 = list2;
      if (this.mShareData != null) {
        Bundle bundle = shareTarget.toBundle();
        intent.putExtra(v416f9e89.xbd520268("1481"), bundle);
        bundle = this.mShareData.toBundle();
        intent.putExtra(v416f9e89.xbd520268("1482"), bundle);
        list1 = list2;
        if (this.mShareData.uris != null)
          list1 = this.mShareData.uris; 
      } 
    } 
    Bundle bundle2 = this.mDisplayMode.toBundle();
    intent.putExtra(v416f9e89.xbd520268("1483"), bundle2);
    int i = this.mScreenOrientation;
    intent.putExtra(v416f9e89.xbd520268("1484"), i);
    return new TrustedWebActivityIntent(intent, (List)list1);
  }
  
  public CustomTabsIntent buildCustomTabsIntent() {
    return this.mIntentBuilder.build();
  }
  
  public TrustedWebActivityDisplayMode getDisplayMode() {
    return this.mDisplayMode;
  }
  
  public Uri getUri() {
    return this.mUri;
  }
  
  public TrustedWebActivityIntentBuilder setAdditionalTrustedOrigins(List<String> paramList) {
    this.mAdditionalTrustedOrigins = paramList;
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setColorScheme(int paramInt) {
    this.mIntentBuilder.setColorScheme(paramInt);
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setColorSchemeParams(int paramInt, CustomTabColorSchemeParams paramCustomTabColorSchemeParams) {
    this.mIntentBuilder.setColorSchemeParams(paramInt, paramCustomTabColorSchemeParams);
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setDefaultColorSchemeParams(CustomTabColorSchemeParams paramCustomTabColorSchemeParams) {
    this.mIntentBuilder.setDefaultColorSchemeParams(paramCustomTabColorSchemeParams);
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setDisplayMode(TrustedWebActivityDisplayMode paramTrustedWebActivityDisplayMode) {
    this.mDisplayMode = paramTrustedWebActivityDisplayMode;
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setNavigationBarColor(int paramInt) {
    this.mIntentBuilder.setNavigationBarColor(paramInt);
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setNavigationBarDividerColor(int paramInt) {
    this.mIntentBuilder.setNavigationBarDividerColor(paramInt);
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setScreenOrientation(int paramInt) {
    this.mScreenOrientation = paramInt;
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setShareParams(ShareTarget paramShareTarget, ShareData paramShareData) {
    this.mShareTarget = paramShareTarget;
    this.mShareData = paramShareData;
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setSplashScreenParams(Bundle paramBundle) {
    this.mSplashScreenParams = paramBundle;
    return this;
  }
  
  public TrustedWebActivityIntentBuilder setToolbarColor(int paramInt) {
    this.mIntentBuilder.setToolbarColor(paramInt);
    return this;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\trusted\TrustedWebActivityIntentBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */