package androidx.browser.trusted.splashscreens;

import h8800e55c.pc41fcc5f.v416f9e89;

public final class SplashScreenVersion {
  public static final String V1 = v416f9e89.xbd520268("1691");
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\trusted\splashscreens\SplashScreenVersion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */