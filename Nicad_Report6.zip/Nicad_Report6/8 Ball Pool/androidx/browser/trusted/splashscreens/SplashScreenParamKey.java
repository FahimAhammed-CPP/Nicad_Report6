package androidx.browser.trusted.splashscreens;

import h8800e55c.pc41fcc5f.v416f9e89;

public final class SplashScreenParamKey {
  public static final String KEY_BACKGROUND_COLOR = v416f9e89.xbd520268("1674");
  
  public static final String KEY_FADE_OUT_DURATION_MS = v416f9e89.xbd520268("1675");
  
  public static final String KEY_IMAGE_TRANSFORMATION_MATRIX = v416f9e89.xbd520268("1676");
  
  public static final String KEY_SCALE_TYPE = v416f9e89.xbd520268("1677");
  
  public static final String KEY_VERSION = v416f9e89.xbd520268("1678");
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\browser\trusted\splashscreens\SplashScreenParamKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */