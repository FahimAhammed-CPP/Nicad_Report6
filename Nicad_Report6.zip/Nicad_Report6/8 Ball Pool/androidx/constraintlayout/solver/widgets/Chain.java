package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.LinearSystem;

class Chain {
  private static final boolean DEBUG = false;
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt) {
    byte b;
    int i;
    ChainHead[] arrayOfChainHead;
    int j = 0;
    if (paramInt == 0) {
      i = paramConstraintWidgetContainer.mHorizontalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mHorizontalChainsArray;
      b = 0;
    } else {
      b = 2;
      i = paramConstraintWidgetContainer.mVerticalChainsSize;
      arrayOfChainHead = paramConstraintWidgetContainer.mVerticalChainsArray;
    } 
    while (j < i) {
      ChainHead chainHead = arrayOfChainHead[j];
      chainHead.define();
      applyChainConstraints(paramConstraintWidgetContainer, paramLinearSystem, paramInt, b, chainHead);
      j++;
    } 
  }
  
  static void applyChainConstraints(ConstraintWidgetContainer paramConstraintWidgetContainer, LinearSystem paramLinearSystem, int paramInt1, int paramInt2, ChainHead paramChainHead) {
    // Byte code:
    //   0: aload #4
    //   2: getfield mFirst : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   5: astore #26
    //   7: aload #4
    //   9: getfield mLast : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   12: astore #23
    //   14: aload #4
    //   16: getfield mFirstVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   19: astore #20
    //   21: aload #4
    //   23: getfield mLastVisibleWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   26: astore #24
    //   28: aload #4
    //   30: getfield mHead : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   33: astore #18
    //   35: aload #4
    //   37: getfield mTotalWeight : F
    //   40: fstore #5
    //   42: aload #4
    //   44: getfield mFirstMatchConstraintWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   47: astore #17
    //   49: aload #4
    //   51: getfield mLastMatchConstraintWidget : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   54: astore #17
    //   56: aload_0
    //   57: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   60: iload_2
    //   61: aaload
    //   62: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.WRAP_CONTENT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   65: if_acmpne -> 74
    //   68: iconst_1
    //   69: istore #12
    //   71: goto -> 77
    //   74: iconst_0
    //   75: istore #12
    //   77: iload_2
    //   78: ifne -> 136
    //   81: aload #18
    //   83: getfield mHorizontalChainStyle : I
    //   86: ifne -> 95
    //   89: iconst_1
    //   90: istore #8
    //   92: goto -> 98
    //   95: iconst_0
    //   96: istore #8
    //   98: aload #18
    //   100: getfield mHorizontalChainStyle : I
    //   103: iconst_1
    //   104: if_icmpne -> 113
    //   107: iconst_1
    //   108: istore #9
    //   110: goto -> 116
    //   113: iconst_0
    //   114: istore #9
    //   116: iload #8
    //   118: istore #10
    //   120: iload #9
    //   122: istore #11
    //   124: aload #18
    //   126: getfield mHorizontalChainStyle : I
    //   129: iconst_2
    //   130: if_icmpne -> 198
    //   133: goto -> 188
    //   136: aload #18
    //   138: getfield mVerticalChainStyle : I
    //   141: ifne -> 150
    //   144: iconst_1
    //   145: istore #8
    //   147: goto -> 153
    //   150: iconst_0
    //   151: istore #8
    //   153: aload #18
    //   155: getfield mVerticalChainStyle : I
    //   158: iconst_1
    //   159: if_icmpne -> 168
    //   162: iconst_1
    //   163: istore #9
    //   165: goto -> 171
    //   168: iconst_0
    //   169: istore #9
    //   171: iload #8
    //   173: istore #10
    //   175: iload #9
    //   177: istore #11
    //   179: aload #18
    //   181: getfield mVerticalChainStyle : I
    //   184: iconst_2
    //   185: if_icmpne -> 198
    //   188: iconst_1
    //   189: istore #13
    //   191: iload #8
    //   193: istore #10
    //   195: goto -> 205
    //   198: iconst_0
    //   199: istore #13
    //   201: iload #11
    //   203: istore #9
    //   205: aload #26
    //   207: astore #19
    //   209: iconst_0
    //   210: istore #8
    //   212: iload #9
    //   214: istore #11
    //   216: aconst_null
    //   217: astore #25
    //   219: aconst_null
    //   220: astore #21
    //   222: iload #8
    //   224: ifne -> 630
    //   227: aload #19
    //   229: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   232: iload_3
    //   233: aaload
    //   234: astore #17
    //   236: iload #13
    //   238: ifeq -> 247
    //   241: iconst_1
    //   242: istore #9
    //   244: goto -> 250
    //   247: iconst_4
    //   248: istore #9
    //   250: aload #17
    //   252: invokevirtual getMargin : ()I
    //   255: istore #16
    //   257: aload #19
    //   259: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   262: iload_2
    //   263: aaload
    //   264: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   267: if_acmpne -> 286
    //   270: aload #19
    //   272: getfield mResolvedMatchConstraintDefault : [I
    //   275: iload_2
    //   276: iaload
    //   277: ifne -> 286
    //   280: iconst_1
    //   281: istore #15
    //   283: goto -> 289
    //   286: iconst_0
    //   287: istore #15
    //   289: iload #16
    //   291: istore #14
    //   293: aload #17
    //   295: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   298: ifnull -> 325
    //   301: iload #16
    //   303: istore #14
    //   305: aload #19
    //   307: aload #26
    //   309: if_acmpeq -> 325
    //   312: iload #16
    //   314: aload #17
    //   316: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   319: invokevirtual getMargin : ()I
    //   322: iadd
    //   323: istore #14
    //   325: iload #13
    //   327: ifeq -> 350
    //   330: aload #19
    //   332: aload #26
    //   334: if_acmpeq -> 350
    //   337: aload #19
    //   339: aload #20
    //   341: if_acmpeq -> 350
    //   344: iconst_5
    //   345: istore #9
    //   347: goto -> 350
    //   350: aload #17
    //   352: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   355: ifnull -> 451
    //   358: aload #19
    //   360: aload #20
    //   362: if_acmpne -> 389
    //   365: aload_1
    //   366: aload #17
    //   368: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   371: aload #17
    //   373: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   376: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   379: iload #14
    //   381: bipush #6
    //   383: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   386: goto -> 410
    //   389: aload_1
    //   390: aload #17
    //   392: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   395: aload #17
    //   397: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   400: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   403: iload #14
    //   405: bipush #8
    //   407: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   410: iload #15
    //   412: ifeq -> 426
    //   415: iload #13
    //   417: ifne -> 426
    //   420: iconst_5
    //   421: istore #9
    //   423: goto -> 426
    //   426: aload_1
    //   427: aload #17
    //   429: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   432: aload #17
    //   434: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   437: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   440: iload #14
    //   442: iload #9
    //   444: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   447: pop
    //   448: goto -> 451
    //   451: iload #12
    //   453: ifeq -> 536
    //   456: aload #19
    //   458: invokevirtual getVisibility : ()I
    //   461: bipush #8
    //   463: if_icmpeq -> 510
    //   466: aload #19
    //   468: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   471: iload_2
    //   472: aaload
    //   473: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   476: if_acmpne -> 510
    //   479: aload_1
    //   480: aload #19
    //   482: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   485: iload_3
    //   486: iconst_1
    //   487: iadd
    //   488: aaload
    //   489: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   492: aload #19
    //   494: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   497: iload_3
    //   498: aaload
    //   499: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   502: iconst_0
    //   503: iconst_5
    //   504: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   507: goto -> 510
    //   510: aload_1
    //   511: aload #19
    //   513: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   516: iload_3
    //   517: aaload
    //   518: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   521: aload_0
    //   522: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   525: iload_3
    //   526: aaload
    //   527: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   530: iconst_0
    //   531: bipush #8
    //   533: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   536: aload #19
    //   538: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   541: iload_3
    //   542: iconst_1
    //   543: iadd
    //   544: aaload
    //   545: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   548: astore #22
    //   550: aload #21
    //   552: astore #17
    //   554: aload #22
    //   556: ifnull -> 612
    //   559: aload #22
    //   561: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   564: astore #22
    //   566: aload #21
    //   568: astore #17
    //   570: aload #22
    //   572: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   575: iload_3
    //   576: aaload
    //   577: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   580: ifnull -> 612
    //   583: aload #22
    //   585: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   588: iload_3
    //   589: aaload
    //   590: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   593: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   596: aload #19
    //   598: if_acmpeq -> 608
    //   601: aload #21
    //   603: astore #17
    //   605: goto -> 612
    //   608: aload #22
    //   610: astore #17
    //   612: aload #17
    //   614: ifnull -> 624
    //   617: aload #17
    //   619: astore #19
    //   621: goto -> 627
    //   624: iconst_1
    //   625: istore #8
    //   627: goto -> 216
    //   630: aload #24
    //   632: ifnull -> 826
    //   635: aload #23
    //   637: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   640: astore #17
    //   642: iload_3
    //   643: iconst_1
    //   644: iadd
    //   645: istore #9
    //   647: aload #17
    //   649: iload #9
    //   651: aaload
    //   652: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   655: ifnull -> 826
    //   658: aload #24
    //   660: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   663: iload #9
    //   665: aaload
    //   666: astore #17
    //   668: aload #24
    //   670: getfield mListDimensionBehaviors : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   673: iload_2
    //   674: aaload
    //   675: getstatic androidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour.MATCH_CONSTRAINT : Landroidx/constraintlayout/solver/widgets/ConstraintWidget$DimensionBehaviour;
    //   678: if_acmpne -> 697
    //   681: aload #24
    //   683: getfield mResolvedMatchConstraintDefault : [I
    //   686: iload_2
    //   687: iaload
    //   688: ifne -> 697
    //   691: iconst_1
    //   692: istore #8
    //   694: goto -> 700
    //   697: iconst_0
    //   698: istore #8
    //   700: iload #8
    //   702: ifeq -> 750
    //   705: iload #13
    //   707: ifne -> 750
    //   710: aload #17
    //   712: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   715: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   718: aload_0
    //   719: if_acmpne -> 750
    //   722: aload_1
    //   723: aload #17
    //   725: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   728: aload #17
    //   730: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   733: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   736: aload #17
    //   738: invokevirtual getMargin : ()I
    //   741: ineg
    //   742: iconst_5
    //   743: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   746: pop
    //   747: goto -> 792
    //   750: iload #13
    //   752: ifeq -> 792
    //   755: aload #17
    //   757: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   760: getfield mOwner : Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   763: aload_0
    //   764: if_acmpne -> 792
    //   767: aload_1
    //   768: aload #17
    //   770: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   773: aload #17
    //   775: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   778: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   781: aload #17
    //   783: invokevirtual getMargin : ()I
    //   786: ineg
    //   787: iconst_4
    //   788: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   791: pop
    //   792: aload_1
    //   793: aload #17
    //   795: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   798: aload #23
    //   800: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   803: iload #9
    //   805: aaload
    //   806: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   809: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   812: aload #17
    //   814: invokevirtual getMargin : ()I
    //   817: ineg
    //   818: bipush #6
    //   820: invokevirtual addLowerThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   823: goto -> 826
    //   826: iload #12
    //   828: ifeq -> 876
    //   831: aload_0
    //   832: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   835: astore_0
    //   836: iload_3
    //   837: iconst_1
    //   838: iadd
    //   839: istore #8
    //   841: aload_1
    //   842: aload_0
    //   843: iload #8
    //   845: aaload
    //   846: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   849: aload #23
    //   851: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   854: iload #8
    //   856: aaload
    //   857: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   860: aload #23
    //   862: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   865: iload #8
    //   867: aaload
    //   868: invokevirtual getMargin : ()I
    //   871: bipush #8
    //   873: invokevirtual addGreaterThan : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   876: aload #4
    //   878: getfield mWeightedMatchConstraintsWidgets : Ljava/util/ArrayList;
    //   881: astore_0
    //   882: aload_0
    //   883: ifnull -> 1178
    //   886: aload_0
    //   887: invokevirtual size : ()I
    //   890: istore #8
    //   892: iload #8
    //   894: iconst_1
    //   895: if_icmple -> 1178
    //   898: aload #4
    //   900: getfield mHasUndefinedWeights : Z
    //   903: ifeq -> 925
    //   906: aload #4
    //   908: getfield mHasComplexMatchWeights : Z
    //   911: ifne -> 925
    //   914: aload #4
    //   916: getfield mWidgetsMatchCount : I
    //   919: i2f
    //   920: fstore #6
    //   922: goto -> 929
    //   925: fload #5
    //   927: fstore #6
    //   929: aconst_null
    //   930: astore #17
    //   932: iconst_0
    //   933: istore #9
    //   935: fconst_0
    //   936: fstore #7
    //   938: iload #9
    //   940: iload #8
    //   942: if_icmpge -> 1178
    //   945: aload_0
    //   946: iload #9
    //   948: invokevirtual get : (I)Ljava/lang/Object;
    //   951: checkcast androidx/constraintlayout/solver/widgets/ConstraintWidget
    //   954: astore #19
    //   956: aload #19
    //   958: getfield mWeight : [F
    //   961: iload_2
    //   962: faload
    //   963: fstore #5
    //   965: fload #5
    //   967: fconst_0
    //   968: fcmpg
    //   969: ifge -> 1018
    //   972: aload #4
    //   974: getfield mHasComplexMatchWeights : Z
    //   977: ifeq -> 1012
    //   980: aload_1
    //   981: aload #19
    //   983: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   986: iload_3
    //   987: iconst_1
    //   988: iadd
    //   989: aaload
    //   990: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   993: aload #19
    //   995: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   998: iload_3
    //   999: aaload
    //   1000: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1003: iconst_0
    //   1004: iconst_4
    //   1005: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1008: pop
    //   1009: goto -> 1055
    //   1012: fconst_1
    //   1013: fstore #5
    //   1015: goto -> 1018
    //   1018: fload #5
    //   1020: fconst_0
    //   1021: fcmpl
    //   1022: ifne -> 1062
    //   1025: aload_1
    //   1026: aload #19
    //   1028: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1031: iload_3
    //   1032: iconst_1
    //   1033: iadd
    //   1034: aaload
    //   1035: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1038: aload #19
    //   1040: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1043: iload_3
    //   1044: aaload
    //   1045: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1048: iconst_0
    //   1049: bipush #8
    //   1051: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   1054: pop
    //   1055: fload #7
    //   1057: fstore #5
    //   1059: goto -> 1165
    //   1062: aload #17
    //   1064: ifnull -> 1161
    //   1067: aload #17
    //   1069: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1072: iload_3
    //   1073: aaload
    //   1074: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1077: astore #21
    //   1079: aload #17
    //   1081: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1084: astore #17
    //   1086: iload_3
    //   1087: iconst_1
    //   1088: iadd
    //   1089: istore #12
    //   1091: aload #17
    //   1093: iload #12
    //   1095: aaload
    //   1096: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1099: astore #17
    //   1101: aload #19
    //   1103: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1106: iload_3
    //   1107: aaload
    //   1108: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1111: astore #22
    //   1113: aload #19
    //   1115: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1118: iload #12
    //   1120: aaload
    //   1121: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1124: astore #27
    //   1126: aload_1
    //   1127: invokevirtual createRow : ()Landroidx/constraintlayout/solver/ArrayRow;
    //   1130: astore #28
    //   1132: aload #28
    //   1134: fload #7
    //   1136: fload #6
    //   1138: fload #5
    //   1140: aload #21
    //   1142: aload #17
    //   1144: aload #22
    //   1146: aload #27
    //   1148: invokevirtual createRowEqualMatchDimensions : (FFFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;)Landroidx/constraintlayout/solver/ArrayRow;
    //   1151: pop
    //   1152: aload_1
    //   1153: aload #28
    //   1155: invokevirtual addConstraint : (Landroidx/constraintlayout/solver/ArrayRow;)V
    //   1158: goto -> 1161
    //   1161: aload #19
    //   1163: astore #17
    //   1165: iload #9
    //   1167: iconst_1
    //   1168: iadd
    //   1169: istore #9
    //   1171: fload #5
    //   1173: fstore #7
    //   1175: goto -> 938
    //   1178: aload #20
    //   1180: ifnull -> 1355
    //   1183: aload #20
    //   1185: aload #24
    //   1187: if_acmpeq -> 1195
    //   1190: iload #13
    //   1192: ifeq -> 1355
    //   1195: aload #26
    //   1197: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1200: iload_3
    //   1201: aaload
    //   1202: astore_0
    //   1203: aload #23
    //   1205: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1208: astore #4
    //   1210: iload_3
    //   1211: iconst_1
    //   1212: iadd
    //   1213: istore #8
    //   1215: aload #4
    //   1217: iload #8
    //   1219: aaload
    //   1220: astore #4
    //   1222: aload_0
    //   1223: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1226: ifnull -> 1240
    //   1229: aload_0
    //   1230: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1233: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1236: astore_0
    //   1237: goto -> 1242
    //   1240: aconst_null
    //   1241: astore_0
    //   1242: aload #4
    //   1244: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1247: ifnull -> 1263
    //   1250: aload #4
    //   1252: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1255: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1258: astore #4
    //   1260: goto -> 1266
    //   1263: aconst_null
    //   1264: astore #4
    //   1266: aload #20
    //   1268: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1271: iload_3
    //   1272: aaload
    //   1273: astore #17
    //   1275: aload #24
    //   1277: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1280: iload #8
    //   1282: aaload
    //   1283: astore #19
    //   1285: aload_0
    //   1286: ifnull -> 2430
    //   1289: aload #4
    //   1291: ifnull -> 2430
    //   1294: iload_2
    //   1295: ifne -> 1308
    //   1298: aload #18
    //   1300: getfield mHorizontalBiasPercent : F
    //   1303: fstore #5
    //   1305: goto -> 1315
    //   1308: aload #18
    //   1310: getfield mVerticalBiasPercent : F
    //   1313: fstore #5
    //   1315: aload #17
    //   1317: invokevirtual getMargin : ()I
    //   1320: istore_2
    //   1321: aload #19
    //   1323: invokevirtual getMargin : ()I
    //   1326: istore #8
    //   1328: aload_1
    //   1329: aload #17
    //   1331: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1334: aload_0
    //   1335: iload_2
    //   1336: fload #5
    //   1338: aload #4
    //   1340: aload #19
    //   1342: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1345: iload #8
    //   1347: bipush #7
    //   1349: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1352: goto -> 2430
    //   1355: iload #10
    //   1357: ifeq -> 1855
    //   1360: aload #20
    //   1362: ifnull -> 1855
    //   1365: aload #4
    //   1367: getfield mWidgetsMatchCount : I
    //   1370: ifle -> 1392
    //   1373: aload #4
    //   1375: getfield mWidgetsCount : I
    //   1378: aload #4
    //   1380: getfield mWidgetsMatchCount : I
    //   1383: if_icmpne -> 1392
    //   1386: iconst_1
    //   1387: istore #12
    //   1389: goto -> 1395
    //   1392: iconst_0
    //   1393: istore #12
    //   1395: aload #20
    //   1397: astore #4
    //   1399: aload #4
    //   1401: astore #19
    //   1403: aload #4
    //   1405: ifnull -> 2430
    //   1408: aload #4
    //   1410: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1413: iload_2
    //   1414: aaload
    //   1415: astore #17
    //   1417: aload #17
    //   1419: ifnull -> 1444
    //   1422: aload #17
    //   1424: invokevirtual getVisibility : ()I
    //   1427: bipush #8
    //   1429: if_icmpne -> 1444
    //   1432: aload #17
    //   1434: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1437: iload_2
    //   1438: aaload
    //   1439: astore #17
    //   1441: goto -> 1417
    //   1444: aload #17
    //   1446: ifnonnull -> 1462
    //   1449: aload #4
    //   1451: aload #24
    //   1453: if_acmpne -> 1459
    //   1456: goto -> 1462
    //   1459: goto -> 1834
    //   1462: aload #4
    //   1464: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1467: iload_3
    //   1468: aaload
    //   1469: astore #21
    //   1471: aload #21
    //   1473: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1476: astore #28
    //   1478: aload #21
    //   1480: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1483: ifnull -> 1499
    //   1486: aload #21
    //   1488: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1491: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1494: astore #18
    //   1496: goto -> 1502
    //   1499: aconst_null
    //   1500: astore #18
    //   1502: aload #19
    //   1504: aload #4
    //   1506: if_acmpeq -> 1525
    //   1509: aload #19
    //   1511: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1514: iload_3
    //   1515: iconst_1
    //   1516: iadd
    //   1517: aaload
    //   1518: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1521: astore_0
    //   1522: goto -> 1577
    //   1525: aload #18
    //   1527: astore_0
    //   1528: aload #4
    //   1530: aload #20
    //   1532: if_acmpne -> 1577
    //   1535: aload #18
    //   1537: astore_0
    //   1538: aload #19
    //   1540: aload #4
    //   1542: if_acmpne -> 1577
    //   1545: aload #26
    //   1547: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1550: iload_3
    //   1551: aaload
    //   1552: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1555: ifnull -> 1575
    //   1558: aload #26
    //   1560: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1563: iload_3
    //   1564: aaload
    //   1565: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1568: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1571: astore_0
    //   1572: goto -> 1577
    //   1575: aconst_null
    //   1576: astore_0
    //   1577: aload #21
    //   1579: invokevirtual getMargin : ()I
    //   1582: istore #13
    //   1584: aload #4
    //   1586: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1589: astore #18
    //   1591: iload_3
    //   1592: iconst_1
    //   1593: iadd
    //   1594: istore #14
    //   1596: aload #18
    //   1598: iload #14
    //   1600: aaload
    //   1601: invokevirtual getMargin : ()I
    //   1604: istore #9
    //   1606: aload #17
    //   1608: ifnull -> 1643
    //   1611: aload #17
    //   1613: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1616: iload_3
    //   1617: aaload
    //   1618: astore #18
    //   1620: aload #18
    //   1622: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1625: astore #21
    //   1627: aload #4
    //   1629: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1632: iload #14
    //   1634: aaload
    //   1635: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1638: astore #22
    //   1640: goto -> 1695
    //   1643: aload #23
    //   1645: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1648: iload #14
    //   1650: aaload
    //   1651: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1654: astore #27
    //   1656: aload #27
    //   1658: ifnull -> 1671
    //   1661: aload #27
    //   1663: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1666: astore #18
    //   1668: goto -> 1674
    //   1671: aconst_null
    //   1672: astore #18
    //   1674: aload #4
    //   1676: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1679: iload #14
    //   1681: aaload
    //   1682: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1685: astore #22
    //   1687: aload #18
    //   1689: astore #21
    //   1691: aload #27
    //   1693: astore #18
    //   1695: iload #9
    //   1697: istore #8
    //   1699: aload #18
    //   1701: ifnull -> 1714
    //   1704: iload #9
    //   1706: aload #18
    //   1708: invokevirtual getMargin : ()I
    //   1711: iadd
    //   1712: istore #8
    //   1714: iload #13
    //   1716: istore #9
    //   1718: aload #19
    //   1720: ifnull -> 1739
    //   1723: iload #13
    //   1725: aload #19
    //   1727: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1730: iload #14
    //   1732: aaload
    //   1733: invokevirtual getMargin : ()I
    //   1736: iadd
    //   1737: istore #9
    //   1739: aload #28
    //   1741: ifnull -> 1459
    //   1744: aload_0
    //   1745: ifnull -> 1459
    //   1748: aload #21
    //   1750: ifnull -> 1459
    //   1753: aload #22
    //   1755: ifnull -> 1459
    //   1758: aload #4
    //   1760: aload #20
    //   1762: if_acmpne -> 1777
    //   1765: aload #20
    //   1767: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1770: iload_3
    //   1771: aaload
    //   1772: invokevirtual getMargin : ()I
    //   1775: istore #9
    //   1777: aload #4
    //   1779: aload #24
    //   1781: if_acmpne -> 1800
    //   1784: aload #24
    //   1786: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1789: iload #14
    //   1791: aaload
    //   1792: invokevirtual getMargin : ()I
    //   1795: istore #8
    //   1797: goto -> 1800
    //   1800: iload #12
    //   1802: ifeq -> 1812
    //   1805: bipush #8
    //   1807: istore #13
    //   1809: goto -> 1815
    //   1812: iconst_5
    //   1813: istore #13
    //   1815: aload_1
    //   1816: aload #28
    //   1818: aload_0
    //   1819: iload #9
    //   1821: ldc 0.5
    //   1823: aload #21
    //   1825: aload #22
    //   1827: iload #8
    //   1829: iload #13
    //   1831: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   1834: aload #4
    //   1836: invokevirtual getVisibility : ()I
    //   1839: bipush #8
    //   1841: if_icmpeq -> 1848
    //   1844: aload #4
    //   1846: astore #19
    //   1848: aload #17
    //   1850: astore #4
    //   1852: goto -> 1403
    //   1855: iload #11
    //   1857: ifeq -> 2430
    //   1860: aload #20
    //   1862: ifnull -> 2430
    //   1865: aload #4
    //   1867: getfield mWidgetsMatchCount : I
    //   1870: ifle -> 1892
    //   1873: aload #4
    //   1875: getfield mWidgetsCount : I
    //   1878: aload #4
    //   1880: getfield mWidgetsMatchCount : I
    //   1883: if_icmpne -> 1892
    //   1886: iconst_1
    //   1887: istore #8
    //   1889: goto -> 1895
    //   1892: iconst_0
    //   1893: istore #8
    //   1895: aload #20
    //   1897: astore #4
    //   1899: aload #4
    //   1901: astore #17
    //   1903: aload #4
    //   1905: ifnull -> 2270
    //   1908: aload #4
    //   1910: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1913: iload_2
    //   1914: aaload
    //   1915: astore_0
    //   1916: aload_0
    //   1917: ifnull -> 1939
    //   1920: aload_0
    //   1921: invokevirtual getVisibility : ()I
    //   1924: bipush #8
    //   1926: if_icmpne -> 1939
    //   1929: aload_0
    //   1930: getfield mNextChainWidget : [Landroidx/constraintlayout/solver/widgets/ConstraintWidget;
    //   1933: iload_2
    //   1934: aaload
    //   1935: astore_0
    //   1936: goto -> 1916
    //   1939: aload #4
    //   1941: aload #20
    //   1943: if_acmpeq -> 2243
    //   1946: aload #4
    //   1948: aload #24
    //   1950: if_acmpeq -> 2243
    //   1953: aload_0
    //   1954: ifnull -> 2243
    //   1957: aload_0
    //   1958: aload #24
    //   1960: if_acmpne -> 1968
    //   1963: aconst_null
    //   1964: astore_0
    //   1965: goto -> 1968
    //   1968: aload #4
    //   1970: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1973: iload_3
    //   1974: aaload
    //   1975: astore #18
    //   1977: aload #18
    //   1979: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   1982: astore #27
    //   1984: aload #18
    //   1986: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1989: ifnull -> 2002
    //   1992: aload #18
    //   1994: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   1997: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2000: astore #19
    //   2002: aload #17
    //   2004: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2007: astore #19
    //   2009: iload_3
    //   2010: iconst_1
    //   2011: iadd
    //   2012: istore #14
    //   2014: aload #19
    //   2016: iload #14
    //   2018: aaload
    //   2019: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2022: astore #28
    //   2024: aload #18
    //   2026: invokevirtual getMargin : ()I
    //   2029: istore #13
    //   2031: aload #4
    //   2033: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2036: iload #14
    //   2038: aaload
    //   2039: invokevirtual getMargin : ()I
    //   2042: istore #12
    //   2044: aload_0
    //   2045: ifnull -> 2090
    //   2048: aload_0
    //   2049: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2052: iload_3
    //   2053: aaload
    //   2054: astore #19
    //   2056: aload #19
    //   2058: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2061: astore #21
    //   2063: aload #19
    //   2065: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2068: ifnull -> 2084
    //   2071: aload #19
    //   2073: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2076: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2079: astore #18
    //   2081: goto -> 2138
    //   2084: aconst_null
    //   2085: astore #18
    //   2087: goto -> 2138
    //   2090: aload #24
    //   2092: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2095: iload_3
    //   2096: aaload
    //   2097: astore #22
    //   2099: aload #22
    //   2101: ifnull -> 2114
    //   2104: aload #22
    //   2106: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2109: astore #19
    //   2111: goto -> 2117
    //   2114: aconst_null
    //   2115: astore #19
    //   2117: aload #4
    //   2119: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2122: iload #14
    //   2124: aaload
    //   2125: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2128: astore #18
    //   2130: aload #19
    //   2132: astore #21
    //   2134: aload #22
    //   2136: astore #19
    //   2138: iload #12
    //   2140: istore #9
    //   2142: aload #19
    //   2144: ifnull -> 2157
    //   2147: iload #12
    //   2149: aload #19
    //   2151: invokevirtual getMargin : ()I
    //   2154: iadd
    //   2155: istore #9
    //   2157: iload #13
    //   2159: istore #12
    //   2161: aload #17
    //   2163: ifnull -> 2182
    //   2166: iload #13
    //   2168: aload #17
    //   2170: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2173: iload #14
    //   2175: aaload
    //   2176: invokevirtual getMargin : ()I
    //   2179: iadd
    //   2180: istore #12
    //   2182: iload #8
    //   2184: ifeq -> 2194
    //   2187: bipush #8
    //   2189: istore #13
    //   2191: goto -> 2197
    //   2194: iconst_4
    //   2195: istore #13
    //   2197: aload #27
    //   2199: ifnull -> 2240
    //   2202: aload #28
    //   2204: ifnull -> 2240
    //   2207: aload #21
    //   2209: ifnull -> 2240
    //   2212: aload #18
    //   2214: ifnull -> 2240
    //   2217: aload_1
    //   2218: aload #27
    //   2220: aload #28
    //   2222: iload #12
    //   2224: ldc 0.5
    //   2226: aload #21
    //   2228: aload #18
    //   2230: iload #9
    //   2232: iload #13
    //   2234: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2237: goto -> 2240
    //   2240: goto -> 2243
    //   2243: aload #4
    //   2245: invokevirtual getVisibility : ()I
    //   2248: bipush #8
    //   2250: if_icmpeq -> 2256
    //   2253: goto -> 2260
    //   2256: aload #17
    //   2258: astore #4
    //   2260: aload #4
    //   2262: astore #17
    //   2264: aload_0
    //   2265: astore #4
    //   2267: goto -> 1903
    //   2270: aload #20
    //   2272: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2275: iload_3
    //   2276: aaload
    //   2277: astore_0
    //   2278: aload #26
    //   2280: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2283: iload_3
    //   2284: aaload
    //   2285: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2288: astore #4
    //   2290: aload #24
    //   2292: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2295: astore #17
    //   2297: iload_3
    //   2298: iconst_1
    //   2299: iadd
    //   2300: istore_2
    //   2301: aload #17
    //   2303: iload_2
    //   2304: aaload
    //   2305: astore #17
    //   2307: aload #23
    //   2309: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2312: iload_2
    //   2313: aaload
    //   2314: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2317: astore #18
    //   2319: aload #4
    //   2321: ifnull -> 2396
    //   2324: aload #20
    //   2326: aload #24
    //   2328: if_acmpeq -> 2353
    //   2331: aload_1
    //   2332: aload_0
    //   2333: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2336: aload #4
    //   2338: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2341: aload_0
    //   2342: invokevirtual getMargin : ()I
    //   2345: iconst_5
    //   2346: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2349: pop
    //   2350: goto -> 2396
    //   2353: aload #18
    //   2355: ifnull -> 2396
    //   2358: aload_1
    //   2359: aload_0
    //   2360: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2363: aload #4
    //   2365: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2368: aload_0
    //   2369: invokevirtual getMargin : ()I
    //   2372: ldc 0.5
    //   2374: aload #17
    //   2376: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2379: aload #18
    //   2381: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2384: aload #17
    //   2386: invokevirtual getMargin : ()I
    //   2389: iconst_5
    //   2390: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2393: goto -> 2396
    //   2396: aload #18
    //   2398: ifnull -> 2430
    //   2401: aload #20
    //   2403: aload #24
    //   2405: if_acmpeq -> 2430
    //   2408: aload_1
    //   2409: aload #17
    //   2411: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2414: aload #18
    //   2416: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2419: aload #17
    //   2421: invokevirtual getMargin : ()I
    //   2424: ineg
    //   2425: iconst_5
    //   2426: invokevirtual addEquality : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)Landroidx/constraintlayout/solver/ArrayRow;
    //   2429: pop
    //   2430: iload #10
    //   2432: ifne -> 2440
    //   2435: iload #11
    //   2437: ifeq -> 2650
    //   2440: aload #20
    //   2442: ifnull -> 2650
    //   2445: aload #20
    //   2447: aload #24
    //   2449: if_acmpeq -> 2650
    //   2452: aload #20
    //   2454: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2457: iload_3
    //   2458: aaload
    //   2459: astore #17
    //   2461: aload #24
    //   2463: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2466: astore_0
    //   2467: iload_3
    //   2468: iconst_1
    //   2469: iadd
    //   2470: istore_2
    //   2471: aload_0
    //   2472: iload_2
    //   2473: aaload
    //   2474: astore #18
    //   2476: aload #17
    //   2478: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2481: ifnull -> 2497
    //   2484: aload #17
    //   2486: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2489: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2492: astore #4
    //   2494: goto -> 2500
    //   2497: aconst_null
    //   2498: astore #4
    //   2500: aload #18
    //   2502: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2505: ifnull -> 2520
    //   2508: aload #18
    //   2510: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2513: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2516: astore_0
    //   2517: goto -> 2522
    //   2520: aconst_null
    //   2521: astore_0
    //   2522: aload #23
    //   2524: aload #24
    //   2526: if_acmpeq -> 2561
    //   2529: aload #23
    //   2531: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2534: iload_2
    //   2535: aaload
    //   2536: astore #19
    //   2538: aload #25
    //   2540: astore_0
    //   2541: aload #19
    //   2543: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2546: ifnull -> 2558
    //   2549: aload #19
    //   2551: getfield mTarget : Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2554: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2557: astore_0
    //   2558: goto -> 2561
    //   2561: aload #20
    //   2563: aload #24
    //   2565: if_acmpne -> 2586
    //   2568: aload #20
    //   2570: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2573: iload_3
    //   2574: aaload
    //   2575: astore #17
    //   2577: aload #20
    //   2579: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2582: iload_2
    //   2583: aaload
    //   2584: astore #18
    //   2586: aload #4
    //   2588: ifnull -> 2650
    //   2591: aload_0
    //   2592: ifnull -> 2650
    //   2595: aload #17
    //   2597: invokevirtual getMargin : ()I
    //   2600: istore_3
    //   2601: aload #24
    //   2603: ifnonnull -> 2613
    //   2606: aload #23
    //   2608: astore #19
    //   2610: goto -> 2617
    //   2613: aload #24
    //   2615: astore #19
    //   2617: aload #19
    //   2619: getfield mListAnchors : [Landroidx/constraintlayout/solver/widgets/ConstraintAnchor;
    //   2622: iload_2
    //   2623: aaload
    //   2624: invokevirtual getMargin : ()I
    //   2627: istore_2
    //   2628: aload_1
    //   2629: aload #17
    //   2631: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2634: aload #4
    //   2636: iload_3
    //   2637: ldc 0.5
    //   2639: aload_0
    //   2640: aload #18
    //   2642: getfield mSolverVariable : Landroidx/constraintlayout/solver/SolverVariable;
    //   2645: iload_2
    //   2646: iconst_5
    //   2647: invokevirtual addCentering : (Landroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;IFLandroidx/constraintlayout/solver/SolverVariable;Landroidx/constraintlayout/solver/SolverVariable;II)V
    //   2650: return
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\solver\widgets\Chain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */