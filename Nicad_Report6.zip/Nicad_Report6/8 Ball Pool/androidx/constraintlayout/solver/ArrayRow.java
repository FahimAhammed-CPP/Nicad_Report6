package androidx.constraintlayout.solver;

import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;

public class ArrayRow implements LinearSystem.Row {
  private static final boolean DEBUG = false;
  
  private static final boolean FULL_NEW_CHECK = false;
  
  float constantValue = 0.0F;
  
  boolean isSimpleDefinition = false;
  
  boolean used = false;
  
  SolverVariable variable = null;
  
  public ArrayRowVariables variables;
  
  ArrayList<SolverVariable> variablesToUpdate = new ArrayList<SolverVariable>();
  
  public ArrayRow() {}
  
  public ArrayRow(Cache paramCache) {
    this.variables = new ArrayLinkedVariables(this, paramCache);
  }
  
  private boolean isNew(SolverVariable paramSolverVariable, LinearSystem paramLinearSystem) {
    return (paramSolverVariable.usageInRowCount <= 1);
  }
  
  private SolverVariable pickPivotInVariables(boolean[] paramArrayOfboolean, SolverVariable paramSolverVariable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   4: invokeinterface getCurrentSize : ()I
    //   9: istore #7
    //   11: aconst_null
    //   12: astore #8
    //   14: iconst_0
    //   15: istore #6
    //   17: fconst_0
    //   18: fstore_3
    //   19: iload #6
    //   21: iload #7
    //   23: if_icmpge -> 167
    //   26: aload_0
    //   27: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   30: iload #6
    //   32: invokeinterface getVariableValue : (I)F
    //   37: fstore #5
    //   39: aload #8
    //   41: astore #9
    //   43: fload_3
    //   44: fstore #4
    //   46: fload #5
    //   48: fconst_0
    //   49: fcmpg
    //   50: ifge -> 151
    //   53: aload_0
    //   54: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   57: iload #6
    //   59: invokeinterface getVariable : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   64: astore #10
    //   66: aload_1
    //   67: ifnull -> 87
    //   70: aload #8
    //   72: astore #9
    //   74: fload_3
    //   75: fstore #4
    //   77: aload_1
    //   78: aload #10
    //   80: getfield id : I
    //   83: baload
    //   84: ifne -> 151
    //   87: aload #8
    //   89: astore #9
    //   91: fload_3
    //   92: fstore #4
    //   94: aload #10
    //   96: aload_2
    //   97: if_acmpeq -> 151
    //   100: aload #10
    //   102: getfield mType : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   105: getstatic androidx/constraintlayout/solver/SolverVariable$Type.SLACK : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   108: if_acmpeq -> 129
    //   111: aload #8
    //   113: astore #9
    //   115: fload_3
    //   116: fstore #4
    //   118: aload #10
    //   120: getfield mType : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   123: getstatic androidx/constraintlayout/solver/SolverVariable$Type.ERROR : Landroidx/constraintlayout/solver/SolverVariable$Type;
    //   126: if_acmpne -> 151
    //   129: aload #8
    //   131: astore #9
    //   133: fload_3
    //   134: fstore #4
    //   136: fload #5
    //   138: fload_3
    //   139: fcmpg
    //   140: ifge -> 151
    //   143: fload #5
    //   145: fstore #4
    //   147: aload #10
    //   149: astore #9
    //   151: iload #6
    //   153: iconst_1
    //   154: iadd
    //   155: istore #6
    //   157: aload #9
    //   159: astore #8
    //   161: fload #4
    //   163: fstore_3
    //   164: goto -> 19
    //   167: aload #8
    //   169: areturn
  }
  
  public ArrayRow addError(LinearSystem paramLinearSystem, int paramInt) {
    this.variables.put(paramLinearSystem.createErrorVariable(paramInt, v416f9e89.xbd520268("2087")), 1.0F);
    this.variables.put(paramLinearSystem.createErrorVariable(paramInt, v416f9e89.xbd520268("2088")), -1.0F);
    return this;
  }
  
  public void addError(SolverVariable paramSolverVariable) {
    int i = paramSolverVariable.strength;
    float f = 1.0F;
    if (i != 1)
      if (paramSolverVariable.strength == 2) {
        f = 1000.0F;
      } else if (paramSolverVariable.strength == 3) {
        f = 1000000.0F;
      } else if (paramSolverVariable.strength == 4) {
        f = 1.0E9F;
      } else if (paramSolverVariable.strength == 5) {
        f = 1.0E12F;
      }  
    this.variables.put(paramSolverVariable, f);
  }
  
  ArrayRow addSingleError(SolverVariable paramSolverVariable, int paramInt) {
    this.variables.put(paramSolverVariable, paramInt);
    return this;
  }
  
  boolean chooseSubject(LinearSystem paramLinearSystem) {
    boolean bool;
    SolverVariable solverVariable = chooseSubjectInVariables(paramLinearSystem);
    if (solverVariable == null) {
      bool = true;
    } else {
      pivot(solverVariable);
      bool = false;
    } 
    if (this.variables.getCurrentSize() == 0)
      this.isSimpleDefinition = true; 
    return bool;
  }
  
  SolverVariable chooseSubjectInVariables(LinearSystem paramLinearSystem) {
    int j = this.variables.getCurrentSize();
    SolverVariable solverVariable2 = null;
    SolverVariable solverVariable1 = null;
    int i = 0;
    boolean bool2 = false;
    boolean bool1 = false;
    float f2 = 0.0F;
    float f1;
    for (f1 = 0.0F;; f1 = f4) {
      float f3;
      float f4;
      boolean bool3;
      boolean bool4;
      SolverVariable solverVariable3;
      SolverVariable solverVariable4;
      if (i < j) {
        float f = this.variables.getVariableValue(i);
        SolverVariable solverVariable = this.variables.getVariable(i);
        if (solverVariable.mType == SolverVariable.Type.UNRESTRICTED) {
          if (solverVariable2 == null) {
            bool3 = isNew(solverVariable, paramLinearSystem);
          } else if (f2 > f) {
            bool3 = isNew(solverVariable, paramLinearSystem);
          } else {
            SolverVariable solverVariable5 = solverVariable2;
            SolverVariable solverVariable6 = solverVariable1;
            bool3 = bool2;
            boolean bool = bool1;
            float f5 = f2;
            float f6 = f1;
            if (!bool2) {
              solverVariable5 = solverVariable2;
              solverVariable6 = solverVariable1;
              bool3 = bool2;
              bool = bool1;
              f5 = f2;
              f6 = f1;
              if (isNew(solverVariable, paramLinearSystem)) {
                bool3 = true;
                solverVariable5 = solverVariable;
                solverVariable6 = solverVariable1;
                bool = bool1;
                f5 = f;
                f6 = f1;
              } 
            } 
            i++;
            solverVariable2 = solverVariable5;
            solverVariable1 = solverVariable6;
            bool2 = bool3;
            bool1 = bool;
            f2 = f5;
            f1 = f6;
          } 
          solverVariable3 = solverVariable;
          solverVariable4 = solverVariable1;
          bool4 = bool1;
          f3 = f;
          f4 = f1;
        } else {
          solverVariable3 = solverVariable2;
          solverVariable4 = solverVariable1;
          bool3 = bool2;
          bool4 = bool1;
          f3 = f2;
          f4 = f1;
          if (solverVariable2 == null) {
            solverVariable3 = solverVariable2;
            solverVariable4 = solverVariable1;
            bool3 = bool2;
            bool4 = bool1;
            f3 = f2;
            f4 = f1;
            if (f < 0.0F) {
              if (solverVariable1 == null) {
                bool3 = isNew(solverVariable, paramLinearSystem);
              } else if (f1 > f) {
                bool3 = isNew(solverVariable, paramLinearSystem);
              } else {
                solverVariable3 = solverVariable2;
                solverVariable4 = solverVariable1;
                bool3 = bool2;
                bool4 = bool1;
                f3 = f2;
                f4 = f1;
                if (!bool1) {
                  solverVariable3 = solverVariable2;
                  solverVariable4 = solverVariable1;
                  bool3 = bool2;
                  bool4 = bool1;
                  f3 = f2;
                  f4 = f1;
                  if (isNew(solverVariable, paramLinearSystem)) {
                    bool4 = true;
                    f4 = f;
                    f3 = f2;
                    bool3 = bool2;
                    solverVariable4 = solverVariable;
                    solverVariable3 = solverVariable2;
                  } 
                } 
                i++;
                solverVariable2 = solverVariable3;
                solverVariable1 = solverVariable4;
                bool2 = bool3;
                bool1 = bool4;
                f2 = f3;
                f1 = f4;
              } 
              bool4 = bool3;
              solverVariable3 = solverVariable2;
              solverVariable4 = solverVariable;
              bool3 = bool2;
              f3 = f2;
              f4 = f;
            } 
          } 
        } 
      } else {
        break;
      } 
      i++;
      solverVariable2 = solverVariable3;
      solverVariable1 = solverVariable4;
      bool2 = bool3;
      bool1 = bool4;
      f2 = f3;
    } 
    return (solverVariable2 != null) ? solverVariable2 : solverVariable1;
  }
  
  public void clear() {
    this.variables.clear();
    this.variable = null;
    this.constantValue = 0.0F;
  }
  
  ArrayRow createRowCentering(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt1, float paramFloat, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, int paramInt2) {
    if (paramSolverVariable2 == paramSolverVariable3) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable2, -2.0F);
      return this;
    } 
    if (paramFloat == 0.5F) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      if (paramInt1 > 0 || paramInt2 > 0) {
        this.constantValue = (-paramInt1 + paramInt2);
        return this;
      } 
    } else {
      if (paramFloat <= 0.0F) {
        this.variables.put(paramSolverVariable1, -1.0F);
        this.variables.put(paramSolverVariable2, 1.0F);
        this.constantValue = paramInt1;
        return this;
      } 
      if (paramFloat >= 1.0F) {
        this.variables.put(paramSolverVariable4, -1.0F);
        this.variables.put(paramSolverVariable3, 1.0F);
        this.constantValue = -paramInt2;
        return this;
      } 
      ArrayRowVariables arrayRowVariables = this.variables;
      float f = 1.0F - paramFloat;
      arrayRowVariables.put(paramSolverVariable1, f * 1.0F);
      this.variables.put(paramSolverVariable2, f * -1.0F);
      this.variables.put(paramSolverVariable3, -1.0F * paramFloat);
      this.variables.put(paramSolverVariable4, 1.0F * paramFloat);
      if (paramInt1 > 0 || paramInt2 > 0)
        this.constantValue = -paramInt1 * f + paramInt2 * paramFloat; 
    } 
    return this;
  }
  
  ArrayRow createRowDefinition(SolverVariable paramSolverVariable, int paramInt) {
    this.variable = paramSolverVariable;
    float f = paramInt;
    paramSolverVariable.computedValue = f;
    this.constantValue = f;
    this.isSimpleDefinition = true;
    return this;
  }
  
  ArrayRow createRowDimensionPercent(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, float paramFloat) {
    this.variables.put(paramSolverVariable1, -1.0F);
    this.variables.put(paramSolverVariable2, paramFloat);
    return this;
  }
  
  public ArrayRow createRowDimensionRatio(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat) {
    this.variables.put(paramSolverVariable1, -1.0F);
    this.variables.put(paramSolverVariable2, 1.0F);
    this.variables.put(paramSolverVariable3, paramFloat);
    this.variables.put(paramSolverVariable4, -paramFloat);
    return this;
  }
  
  public ArrayRow createRowEqualDimension(float paramFloat1, float paramFloat2, float paramFloat3, SolverVariable paramSolverVariable1, int paramInt1, SolverVariable paramSolverVariable2, int paramInt2, SolverVariable paramSolverVariable3, int paramInt3, SolverVariable paramSolverVariable4, int paramInt4) {
    if (paramFloat2 == 0.0F || paramFloat1 == paramFloat3) {
      this.constantValue = (-paramInt1 - paramInt2 + paramInt3 + paramInt4);
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    paramFloat1 = paramFloat1 / paramFloat2 / paramFloat3 / paramFloat2;
    this.constantValue = (-paramInt1 - paramInt2) + paramInt3 * paramFloat1 + paramInt4 * paramFloat1;
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable4, paramFloat1);
    this.variables.put(paramSolverVariable3, -paramFloat1);
    return this;
  }
  
  public ArrayRow createRowEqualMatchDimensions(float paramFloat1, float paramFloat2, float paramFloat3, SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4) {
    this.constantValue = 0.0F;
    if (paramFloat2 == 0.0F || paramFloat1 == paramFloat3) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      this.variables.put(paramSolverVariable4, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    if (paramFloat1 == 0.0F) {
      this.variables.put(paramSolverVariable1, 1.0F);
      this.variables.put(paramSolverVariable2, -1.0F);
      return this;
    } 
    if (paramFloat3 == 0.0F) {
      this.variables.put(paramSolverVariable3, 1.0F);
      this.variables.put(paramSolverVariable4, -1.0F);
      return this;
    } 
    paramFloat1 = paramFloat1 / paramFloat2 / paramFloat3 / paramFloat2;
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable4, paramFloat1);
    this.variables.put(paramSolverVariable3, -paramFloat1);
    return this;
  }
  
  public ArrayRow createRowEquals(SolverVariable paramSolverVariable, int paramInt) {
    if (paramInt < 0) {
      this.constantValue = (paramInt * -1);
      this.variables.put(paramSolverVariable, 1.0F);
      return this;
    } 
    this.constantValue = paramInt;
    this.variables.put(paramSolverVariable, -1.0F);
    return this;
  }
  
  public ArrayRow createRowEquals(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    return this;
  }
  
  public ArrayRow createRowGreaterThan(SolverVariable paramSolverVariable1, int paramInt, SolverVariable paramSolverVariable2) {
    this.constantValue = paramInt;
    this.variables.put(paramSolverVariable1, -1.0F);
    return this;
  }
  
  public ArrayRow createRowGreaterThan(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      this.variables.put(paramSolverVariable3, 1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable3, -1.0F);
    return this;
  }
  
  public ArrayRow createRowLowerThan(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, int paramInt) {
    int i = 0;
    int j = 0;
    if (paramInt != 0) {
      i = j;
      j = paramInt;
      if (paramInt < 0) {
        j = paramInt * -1;
        i = 1;
      } 
      this.constantValue = j;
    } 
    if (i == 0) {
      this.variables.put(paramSolverVariable1, -1.0F);
      this.variables.put(paramSolverVariable2, 1.0F);
      this.variables.put(paramSolverVariable3, -1.0F);
      return this;
    } 
    this.variables.put(paramSolverVariable1, 1.0F);
    this.variables.put(paramSolverVariable2, -1.0F);
    this.variables.put(paramSolverVariable3, 1.0F);
    return this;
  }
  
  public ArrayRow createRowWithAngle(SolverVariable paramSolverVariable1, SolverVariable paramSolverVariable2, SolverVariable paramSolverVariable3, SolverVariable paramSolverVariable4, float paramFloat) {
    this.variables.put(paramSolverVariable3, 0.5F);
    this.variables.put(paramSolverVariable4, 0.5F);
    this.variables.put(paramSolverVariable1, -0.5F);
    this.variables.put(paramSolverVariable2, -0.5F);
    this.constantValue = -paramFloat;
    return this;
  }
  
  void ensurePositiveConstant() {
    float f = this.constantValue;
    if (f < 0.0F) {
      this.constantValue = f * -1.0F;
      this.variables.invert();
    } 
  }
  
  public SolverVariable getKey() {
    return this.variable;
  }
  
  public SolverVariable getPivotCandidate(LinearSystem paramLinearSystem, boolean[] paramArrayOfboolean) {
    return pickPivotInVariables(paramArrayOfboolean, null);
  }
  
  boolean hasKeyVariable() {
    SolverVariable solverVariable = this.variable;
    return (solverVariable != null && (solverVariable.mType == SolverVariable.Type.UNRESTRICTED || this.constantValue >= 0.0F));
  }
  
  boolean hasVariable(SolverVariable paramSolverVariable) {
    return this.variables.contains(paramSolverVariable);
  }
  
  public void initFromRow(LinearSystem.Row paramRow) {
    if (paramRow instanceof ArrayRow) {
      paramRow = paramRow;
      this.variable = null;
      this.variables.clear();
      for (int i = 0; i < ((ArrayRow)paramRow).variables.getCurrentSize(); i++) {
        SolverVariable solverVariable = ((ArrayRow)paramRow).variables.getVariable(i);
        float f = ((ArrayRow)paramRow).variables.getVariableValue(i);
        this.variables.add(solverVariable, f, true);
      } 
    } 
  }
  
  public boolean isEmpty() {
    return (this.variable == null && this.constantValue == 0.0F && this.variables.getCurrentSize() == 0);
  }
  
  public SolverVariable pickPivot(SolverVariable paramSolverVariable) {
    return pickPivotInVariables(null, paramSolverVariable);
  }
  
  void pivot(SolverVariable paramSolverVariable) {
    SolverVariable solverVariable = this.variable;
    if (solverVariable != null) {
      this.variables.put(solverVariable, -1.0F);
      this.variable = null;
    } 
    float f = this.variables.remove(paramSolverVariable, true) * -1.0F;
    this.variable = paramSolverVariable;
    if (f == 1.0F)
      return; 
    this.constantValue /= f;
    this.variables.divideByAmount(f);
  }
  
  public void reset() {
    this.variable = null;
    this.variables.clear();
    this.constantValue = 0.0F;
    this.isSimpleDefinition = false;
  }
  
  int sizeInBytes() {
    byte b;
    if (this.variable != null) {
      b = 4;
    } else {
      b = 0;
    } 
    return b + 4 + 4 + this.variables.sizeInBytes();
  }
  
  String toReadableString() {
    // Byte code:
    //   0: aload_0
    //   1: getfield variable : Landroidx/constraintlayout/solver/SolverVariable;
    //   4: ifnonnull -> 17
    //   7: ldc '2089'
    //   9: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   12: astore #7
    //   14: goto -> 54
    //   17: new java/lang/StringBuilder
    //   20: dup
    //   21: invokespecial <init> : ()V
    //   24: astore #7
    //   26: aload #7
    //   28: ldc '2090'
    //   30: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   33: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   36: pop
    //   37: aload #7
    //   39: aload_0
    //   40: getfield variable : Landroidx/constraintlayout/solver/SolverVariable;
    //   43: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   46: pop
    //   47: aload #7
    //   49: invokevirtual toString : ()Ljava/lang/String;
    //   52: astore #7
    //   54: new java/lang/StringBuilder
    //   57: dup
    //   58: invokespecial <init> : ()V
    //   61: astore #8
    //   63: aload #8
    //   65: aload #7
    //   67: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: pop
    //   71: aload #8
    //   73: ldc '2091'
    //   75: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload #8
    //   84: invokevirtual toString : ()Ljava/lang/String;
    //   87: astore #7
    //   89: aload_0
    //   90: getfield constantValue : F
    //   93: fstore_1
    //   94: iconst_0
    //   95: istore #4
    //   97: fload_1
    //   98: fconst_0
    //   99: fcmpl
    //   100: ifeq -> 142
    //   103: new java/lang/StringBuilder
    //   106: dup
    //   107: invokespecial <init> : ()V
    //   110: astore #8
    //   112: aload #8
    //   114: aload #7
    //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: pop
    //   120: aload #8
    //   122: aload_0
    //   123: getfield constantValue : F
    //   126: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   129: pop
    //   130: aload #8
    //   132: invokevirtual toString : ()Ljava/lang/String;
    //   135: astore #7
    //   137: iconst_1
    //   138: istore_3
    //   139: goto -> 144
    //   142: iconst_0
    //   143: istore_3
    //   144: aload_0
    //   145: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   148: invokeinterface getCurrentSize : ()I
    //   153: istore #5
    //   155: iload #4
    //   157: iload #5
    //   159: if_icmpge -> 456
    //   162: aload_0
    //   163: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   166: iload #4
    //   168: invokeinterface getVariable : (I)Landroidx/constraintlayout/solver/SolverVariable;
    //   173: astore #8
    //   175: aload #8
    //   177: ifnonnull -> 183
    //   180: goto -> 447
    //   183: aload_0
    //   184: getfield variables : Landroidx/constraintlayout/solver/ArrayRow$ArrayRowVariables;
    //   187: iload #4
    //   189: invokeinterface getVariableValue : (I)F
    //   194: fstore_2
    //   195: fload_2
    //   196: fconst_0
    //   197: fcmpl
    //   198: istore #6
    //   200: iload #6
    //   202: ifne -> 208
    //   205: goto -> 447
    //   208: aload #8
    //   210: invokevirtual toString : ()Ljava/lang/String;
    //   213: astore #9
    //   215: iload_3
    //   216: ifne -> 269
    //   219: aload #7
    //   221: astore #8
    //   223: fload_2
    //   224: fstore_1
    //   225: fload_2
    //   226: fconst_0
    //   227: fcmpg
    //   228: ifge -> 354
    //   231: new java/lang/StringBuilder
    //   234: dup
    //   235: invokespecial <init> : ()V
    //   238: astore #8
    //   240: aload #8
    //   242: aload #7
    //   244: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   247: pop
    //   248: aload #8
    //   250: ldc '2092'
    //   252: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: pop
    //   259: aload #8
    //   261: invokevirtual toString : ()Ljava/lang/String;
    //   264: astore #8
    //   266: goto -> 349
    //   269: iload #6
    //   271: ifle -> 314
    //   274: new java/lang/StringBuilder
    //   277: dup
    //   278: invokespecial <init> : ()V
    //   281: astore #8
    //   283: aload #8
    //   285: aload #7
    //   287: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   290: pop
    //   291: aload #8
    //   293: ldc '2093'
    //   295: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   298: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   301: pop
    //   302: aload #8
    //   304: invokevirtual toString : ()Ljava/lang/String;
    //   307: astore #8
    //   309: fload_2
    //   310: fstore_1
    //   311: goto -> 354
    //   314: new java/lang/StringBuilder
    //   317: dup
    //   318: invokespecial <init> : ()V
    //   321: astore #8
    //   323: aload #8
    //   325: aload #7
    //   327: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   330: pop
    //   331: aload #8
    //   333: ldc '2094'
    //   335: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: pop
    //   342: aload #8
    //   344: invokevirtual toString : ()Ljava/lang/String;
    //   347: astore #8
    //   349: fload_2
    //   350: ldc -1.0
    //   352: fmul
    //   353: fstore_1
    //   354: fload_1
    //   355: fconst_1
    //   356: fcmpl
    //   357: ifne -> 395
    //   360: new java/lang/StringBuilder
    //   363: dup
    //   364: invokespecial <init> : ()V
    //   367: astore #7
    //   369: aload #7
    //   371: aload #8
    //   373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: pop
    //   377: aload #7
    //   379: aload #9
    //   381: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: aload #7
    //   387: invokevirtual toString : ()Ljava/lang/String;
    //   390: astore #7
    //   392: goto -> 445
    //   395: new java/lang/StringBuilder
    //   398: dup
    //   399: invokespecial <init> : ()V
    //   402: astore #7
    //   404: aload #7
    //   406: aload #8
    //   408: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   411: pop
    //   412: aload #7
    //   414: fload_1
    //   415: invokevirtual append : (F)Ljava/lang/StringBuilder;
    //   418: pop
    //   419: aload #7
    //   421: ldc '2095'
    //   423: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   426: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   429: pop
    //   430: aload #7
    //   432: aload #9
    //   434: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   437: pop
    //   438: aload #7
    //   440: invokevirtual toString : ()Ljava/lang/String;
    //   443: astore #7
    //   445: iconst_1
    //   446: istore_3
    //   447: iload #4
    //   449: iconst_1
    //   450: iadd
    //   451: istore #4
    //   453: goto -> 155
    //   456: aload #7
    //   458: astore #8
    //   460: iload_3
    //   461: ifne -> 499
    //   464: new java/lang/StringBuilder
    //   467: dup
    //   468: invokespecial <init> : ()V
    //   471: astore #8
    //   473: aload #8
    //   475: aload #7
    //   477: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   480: pop
    //   481: aload #8
    //   483: ldc '2096'
    //   485: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   488: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   491: pop
    //   492: aload #8
    //   494: invokevirtual toString : ()Ljava/lang/String;
    //   497: astore #8
    //   499: aload #8
    //   501: areturn
  }
  
  public String toString() {
    return toReadableString();
  }
  
  public void updateFromFinalVariable(LinearSystem paramLinearSystem, SolverVariable paramSolverVariable, boolean paramBoolean) {
    if (!paramSolverVariable.isFinalValue)
      return; 
    float f = this.variables.get(paramSolverVariable);
    this.constantValue += paramSolverVariable.computedValue * f;
    this.variables.remove(paramSolverVariable, paramBoolean);
    if (paramBoolean)
      paramSolverVariable.removeFromRow(this); 
  }
  
  public void updateFromRow(ArrayRow paramArrayRow, boolean paramBoolean) {
    float f = this.variables.use(paramArrayRow, paramBoolean);
    this.constantValue += paramArrayRow.constantValue * f;
    if (paramBoolean)
      paramArrayRow.variable.removeFromRow(this); 
  }
  
  public void updateFromSystem(LinearSystem paramLinearSystem) {
    if (paramLinearSystem.mRows.length == 0)
      return; 
    for (boolean bool = false; !bool; bool = true) {
      int j = this.variables.getCurrentSize();
      for (int i = 0; i < j; i++) {
        SolverVariable solverVariable = this.variables.getVariable(i);
        if (solverVariable.definitionId != -1 || solverVariable.isFinalValue)
          this.variablesToUpdate.add(solverVariable); 
      } 
      if (this.variablesToUpdate.size() > 0) {
        for (SolverVariable solverVariable : this.variablesToUpdate) {
          if (solverVariable.isFinalValue) {
            updateFromFinalVariable(paramLinearSystem, solverVariable, true);
            continue;
          } 
          updateFromRow(paramLinearSystem.mRows[solverVariable.definitionId], true);
        } 
        this.variablesToUpdate.clear();
        continue;
      } 
    } 
  }
  
  public static interface ArrayRowVariables {
    void add(SolverVariable param1SolverVariable, float param1Float, boolean param1Boolean);
    
    void clear();
    
    boolean contains(SolverVariable param1SolverVariable);
    
    void display();
    
    void divideByAmount(float param1Float);
    
    float get(SolverVariable param1SolverVariable);
    
    int getCurrentSize();
    
    SolverVariable getVariable(int param1Int);
    
    float getVariableValue(int param1Int);
    
    int indexOf(SolverVariable param1SolverVariable);
    
    void invert();
    
    void put(SolverVariable param1SolverVariable, float param1Float);
    
    float remove(SolverVariable param1SolverVariable, boolean param1Boolean);
    
    int sizeInBytes();
    
    float use(ArrayRow param1ArrayRow, boolean param1Boolean);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\solver\ArrayRow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */