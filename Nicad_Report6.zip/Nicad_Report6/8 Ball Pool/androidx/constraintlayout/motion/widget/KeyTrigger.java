package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import androidx.constraintlayout.widget.R;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;

public class KeyTrigger extends Key {
  public static final int KEY_TYPE = 5;
  
  static final String NAME = v416f9e89.xbd520268("1792");
  
  private static final String TAG = v416f9e89.xbd520268("1793");
  
  RectF mCollisionRect = new RectF();
  
  private String mCross = null;
  
  private int mCurveFit = -1;
  
  private Method mFireCross;
  
  private boolean mFireCrossReset = true;
  
  private float mFireLastPos;
  
  private Method mFireNegativeCross;
  
  private boolean mFireNegativeReset = true;
  
  private Method mFirePositiveCross;
  
  private boolean mFirePositiveReset = true;
  
  private float mFireThreshold = Float.NaN;
  
  private String mNegativeCross = null;
  
  private String mPositiveCross = null;
  
  private boolean mPostLayout = false;
  
  RectF mTargetRect = new RectF();
  
  private int mTriggerCollisionId = UNSET;
  
  private View mTriggerCollisionView = null;
  
  private int mTriggerID = UNSET;
  
  private int mTriggerReceiver = UNSET;
  
  float mTriggerSlack = 0.1F;
  
  private void setUpRect(RectF paramRectF, View paramView, boolean paramBoolean) {
    paramRectF.top = paramView.getTop();
    paramRectF.bottom = paramView.getBottom();
    paramRectF.left = paramView.getLeft();
    paramRectF.right = paramView.getRight();
    if (paramBoolean)
      paramView.getMatrix().mapRect(paramRectF); 
  }
  
  public void addValues(HashMap<String, SplineSet> paramHashMap) {}
  
  public void conditionallyFire(float paramFloat, View paramView) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTriggerCollisionId : I
    //   4: istore #5
    //   6: getstatic androidx/constraintlayout/motion/widget/KeyTrigger.UNSET : I
    //   9: istore #6
    //   11: iconst_1
    //   12: istore #7
    //   14: iload #5
    //   16: iload #6
    //   18: if_icmpeq -> 192
    //   21: aload_0
    //   22: getfield mTriggerCollisionView : Landroid/view/View;
    //   25: ifnonnull -> 46
    //   28: aload_0
    //   29: aload_2
    //   30: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   33: checkcast android/view/ViewGroup
    //   36: aload_0
    //   37: getfield mTriggerCollisionId : I
    //   40: invokevirtual findViewById : (I)Landroid/view/View;
    //   43: putfield mTriggerCollisionView : Landroid/view/View;
    //   46: aload_0
    //   47: aload_0
    //   48: getfield mCollisionRect : Landroid/graphics/RectF;
    //   51: aload_0
    //   52: getfield mTriggerCollisionView : Landroid/view/View;
    //   55: aload_0
    //   56: getfield mPostLayout : Z
    //   59: invokespecial setUpRect : (Landroid/graphics/RectF;Landroid/view/View;Z)V
    //   62: aload_0
    //   63: aload_0
    //   64: getfield mTargetRect : Landroid/graphics/RectF;
    //   67: aload_2
    //   68: aload_0
    //   69: getfield mPostLayout : Z
    //   72: invokespecial setUpRect : (Landroid/graphics/RectF;Landroid/view/View;Z)V
    //   75: aload_0
    //   76: getfield mCollisionRect : Landroid/graphics/RectF;
    //   79: aload_0
    //   80: getfield mTargetRect : Landroid/graphics/RectF;
    //   83: invokevirtual intersect : (Landroid/graphics/RectF;)Z
    //   86: ifeq -> 142
    //   89: aload_0
    //   90: getfield mFireCrossReset : Z
    //   93: ifeq -> 107
    //   96: aload_0
    //   97: iconst_0
    //   98: putfield mFireCrossReset : Z
    //   101: iconst_1
    //   102: istore #5
    //   104: goto -> 110
    //   107: iconst_0
    //   108: istore #5
    //   110: aload_0
    //   111: getfield mFirePositiveReset : Z
    //   114: ifeq -> 128
    //   117: aload_0
    //   118: iconst_0
    //   119: putfield mFirePositiveReset : Z
    //   122: iconst_1
    //   123: istore #7
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #7
    //   131: aload_0
    //   132: iconst_1
    //   133: putfield mFireNegativeReset : Z
    //   136: iconst_0
    //   137: istore #6
    //   139: goto -> 406
    //   142: aload_0
    //   143: getfield mFireCrossReset : Z
    //   146: ifne -> 160
    //   149: aload_0
    //   150: iconst_1
    //   151: putfield mFireCrossReset : Z
    //   154: iconst_1
    //   155: istore #5
    //   157: goto -> 163
    //   160: iconst_0
    //   161: istore #5
    //   163: aload_0
    //   164: getfield mFireNegativeReset : Z
    //   167: ifeq -> 181
    //   170: aload_0
    //   171: iconst_0
    //   172: putfield mFireNegativeReset : Z
    //   175: iconst_1
    //   176: istore #6
    //   178: goto -> 184
    //   181: iconst_0
    //   182: istore #6
    //   184: aload_0
    //   185: iconst_1
    //   186: putfield mFirePositiveReset : Z
    //   189: goto -> 403
    //   192: aload_0
    //   193: getfield mFireCrossReset : Z
    //   196: ifeq -> 230
    //   199: aload_0
    //   200: getfield mFireThreshold : F
    //   203: fstore_3
    //   204: fload_1
    //   205: fload_3
    //   206: fsub
    //   207: aload_0
    //   208: getfield mFireLastPos : F
    //   211: fload_3
    //   212: fsub
    //   213: fmul
    //   214: fconst_0
    //   215: fcmpg
    //   216: ifge -> 252
    //   219: aload_0
    //   220: iconst_0
    //   221: putfield mFireCrossReset : Z
    //   224: iconst_1
    //   225: istore #5
    //   227: goto -> 255
    //   230: fload_1
    //   231: aload_0
    //   232: getfield mFireThreshold : F
    //   235: fsub
    //   236: invokestatic abs : (F)F
    //   239: aload_0
    //   240: getfield mTriggerSlack : F
    //   243: fcmpl
    //   244: ifle -> 252
    //   247: aload_0
    //   248: iconst_1
    //   249: putfield mFireCrossReset : Z
    //   252: iconst_0
    //   253: istore #5
    //   255: aload_0
    //   256: getfield mFireNegativeReset : Z
    //   259: ifeq -> 304
    //   262: aload_0
    //   263: getfield mFireThreshold : F
    //   266: fstore_3
    //   267: fload_1
    //   268: fload_3
    //   269: fsub
    //   270: fstore #4
    //   272: aload_0
    //   273: getfield mFireLastPos : F
    //   276: fload_3
    //   277: fsub
    //   278: fload #4
    //   280: fmul
    //   281: fconst_0
    //   282: fcmpg
    //   283: ifge -> 326
    //   286: fload #4
    //   288: fconst_0
    //   289: fcmpg
    //   290: ifge -> 326
    //   293: aload_0
    //   294: iconst_0
    //   295: putfield mFireNegativeReset : Z
    //   298: iconst_1
    //   299: istore #6
    //   301: goto -> 329
    //   304: fload_1
    //   305: aload_0
    //   306: getfield mFireThreshold : F
    //   309: fsub
    //   310: invokestatic abs : (F)F
    //   313: aload_0
    //   314: getfield mTriggerSlack : F
    //   317: fcmpl
    //   318: ifle -> 326
    //   321: aload_0
    //   322: iconst_1
    //   323: putfield mFireNegativeReset : Z
    //   326: iconst_0
    //   327: istore #6
    //   329: aload_0
    //   330: getfield mFirePositiveReset : Z
    //   333: ifeq -> 381
    //   336: aload_0
    //   337: getfield mFireThreshold : F
    //   340: fstore_3
    //   341: fload_1
    //   342: fload_3
    //   343: fsub
    //   344: fstore #4
    //   346: aload_0
    //   347: getfield mFireLastPos : F
    //   350: fload_3
    //   351: fsub
    //   352: fload #4
    //   354: fmul
    //   355: fconst_0
    //   356: fcmpg
    //   357: ifge -> 375
    //   360: fload #4
    //   362: fconst_0
    //   363: fcmpl
    //   364: ifle -> 375
    //   367: aload_0
    //   368: iconst_0
    //   369: putfield mFirePositiveReset : Z
    //   372: goto -> 378
    //   375: iconst_0
    //   376: istore #7
    //   378: goto -> 406
    //   381: fload_1
    //   382: aload_0
    //   383: getfield mFireThreshold : F
    //   386: fsub
    //   387: invokestatic abs : (F)F
    //   390: aload_0
    //   391: getfield mTriggerSlack : F
    //   394: fcmpl
    //   395: ifle -> 403
    //   398: aload_0
    //   399: iconst_1
    //   400: putfield mFirePositiveReset : Z
    //   403: iconst_0
    //   404: istore #7
    //   406: aload_0
    //   407: fload_1
    //   408: putfield mFireLastPos : F
    //   411: iload #6
    //   413: ifne -> 426
    //   416: iload #5
    //   418: ifne -> 426
    //   421: iload #7
    //   423: ifeq -> 443
    //   426: aload_2
    //   427: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   430: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   433: aload_0
    //   434: getfield mTriggerID : I
    //   437: iload #7
    //   439: fload_1
    //   440: invokevirtual fireTrigger : (IZF)V
    //   443: aload_0
    //   444: getfield mTriggerReceiver : I
    //   447: getstatic androidx/constraintlayout/motion/widget/KeyTrigger.UNSET : I
    //   450: if_icmpne -> 456
    //   453: goto -> 471
    //   456: aload_2
    //   457: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   460: checkcast androidx/constraintlayout/motion/widget/MotionLayout
    //   463: aload_0
    //   464: getfield mTriggerReceiver : I
    //   467: invokevirtual findViewById : (I)Landroid/view/View;
    //   470: astore_2
    //   471: ldc '1794'
    //   473: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   476: astore #12
    //   478: ldc '1795'
    //   480: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   483: astore #8
    //   485: ldc '1796'
    //   487: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   490: astore #9
    //   492: ldc '1797'
    //   494: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   497: astore #10
    //   499: ldc '1798'
    //   501: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   504: astore #11
    //   506: iload #6
    //   508: ifeq -> 717
    //   511: aload_0
    //   512: getfield mNegativeCross : Ljava/lang/String;
    //   515: ifnull -> 717
    //   518: aload_0
    //   519: getfield mFireNegativeCross : Ljava/lang/reflect/Method;
    //   522: ifnonnull -> 624
    //   525: aload_0
    //   526: aload_2
    //   527: invokevirtual getClass : ()Ljava/lang/Class;
    //   530: aload_0
    //   531: getfield mNegativeCross : Ljava/lang/String;
    //   534: iconst_0
    //   535: anewarray java/lang/Class
    //   538: invokestatic getMethod : (Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   541: putfield mFireNegativeCross : Ljava/lang/reflect/Method;
    //   544: goto -> 624
    //   547: new java/lang/StringBuilder
    //   550: dup
    //   551: invokespecial <init> : ()V
    //   554: astore #13
    //   556: aload #13
    //   558: aload #12
    //   560: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   563: pop
    //   564: aload #13
    //   566: aload_0
    //   567: getfield mNegativeCross : Ljava/lang/String;
    //   570: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   573: pop
    //   574: aload #13
    //   576: aload #10
    //   578: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   581: pop
    //   582: aload #13
    //   584: aload_2
    //   585: invokevirtual getClass : ()Ljava/lang/Class;
    //   588: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   591: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   594: pop
    //   595: aload #13
    //   597: aload #9
    //   599: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   602: pop
    //   603: aload #13
    //   605: aload_2
    //   606: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   609: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   612: pop
    //   613: aload #11
    //   615: aload #13
    //   617: invokevirtual toString : ()Ljava/lang/String;
    //   620: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   623: pop
    //   624: aload_0
    //   625: getfield mFireNegativeCross : Ljava/lang/reflect/Method;
    //   628: aload_2
    //   629: iconst_0
    //   630: anewarray java/lang/Object
    //   633: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   636: pop
    //   637: goto -> 717
    //   640: new java/lang/StringBuilder
    //   643: dup
    //   644: invokespecial <init> : ()V
    //   647: astore #13
    //   649: aload #13
    //   651: aload #8
    //   653: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   656: pop
    //   657: aload #13
    //   659: aload_0
    //   660: getfield mNegativeCross : Ljava/lang/String;
    //   663: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   666: pop
    //   667: aload #13
    //   669: aload #10
    //   671: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   674: pop
    //   675: aload #13
    //   677: aload_2
    //   678: invokevirtual getClass : ()Ljava/lang/Class;
    //   681: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   684: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   687: pop
    //   688: aload #13
    //   690: aload #9
    //   692: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   695: pop
    //   696: aload #13
    //   698: aload_2
    //   699: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   702: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   705: pop
    //   706: aload #11
    //   708: aload #13
    //   710: invokevirtual toString : ()Ljava/lang/String;
    //   713: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   716: pop
    //   717: iload #7
    //   719: ifeq -> 928
    //   722: aload_0
    //   723: getfield mPositiveCross : Ljava/lang/String;
    //   726: ifnull -> 928
    //   729: aload_0
    //   730: getfield mFirePositiveCross : Ljava/lang/reflect/Method;
    //   733: ifnonnull -> 835
    //   736: aload_0
    //   737: aload_2
    //   738: invokevirtual getClass : ()Ljava/lang/Class;
    //   741: aload_0
    //   742: getfield mPositiveCross : Ljava/lang/String;
    //   745: iconst_0
    //   746: anewarray java/lang/Class
    //   749: invokestatic getMethod : (Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   752: putfield mFirePositiveCross : Ljava/lang/reflect/Method;
    //   755: goto -> 835
    //   758: new java/lang/StringBuilder
    //   761: dup
    //   762: invokespecial <init> : ()V
    //   765: astore #13
    //   767: aload #13
    //   769: aload #12
    //   771: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   774: pop
    //   775: aload #13
    //   777: aload_0
    //   778: getfield mPositiveCross : Ljava/lang/String;
    //   781: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   784: pop
    //   785: aload #13
    //   787: aload #10
    //   789: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   792: pop
    //   793: aload #13
    //   795: aload_2
    //   796: invokevirtual getClass : ()Ljava/lang/Class;
    //   799: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   802: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   805: pop
    //   806: aload #13
    //   808: aload #9
    //   810: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   813: pop
    //   814: aload #13
    //   816: aload_2
    //   817: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   820: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   823: pop
    //   824: aload #11
    //   826: aload #13
    //   828: invokevirtual toString : ()Ljava/lang/String;
    //   831: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   834: pop
    //   835: aload_0
    //   836: getfield mFirePositiveCross : Ljava/lang/reflect/Method;
    //   839: aload_2
    //   840: iconst_0
    //   841: anewarray java/lang/Object
    //   844: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   847: pop
    //   848: goto -> 928
    //   851: new java/lang/StringBuilder
    //   854: dup
    //   855: invokespecial <init> : ()V
    //   858: astore #13
    //   860: aload #13
    //   862: aload #8
    //   864: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   867: pop
    //   868: aload #13
    //   870: aload_0
    //   871: getfield mPositiveCross : Ljava/lang/String;
    //   874: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   877: pop
    //   878: aload #13
    //   880: aload #10
    //   882: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   885: pop
    //   886: aload #13
    //   888: aload_2
    //   889: invokevirtual getClass : ()Ljava/lang/Class;
    //   892: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   895: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   898: pop
    //   899: aload #13
    //   901: aload #9
    //   903: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   906: pop
    //   907: aload #13
    //   909: aload_2
    //   910: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   913: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   916: pop
    //   917: aload #11
    //   919: aload #13
    //   921: invokevirtual toString : ()Ljava/lang/String;
    //   924: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   927: pop
    //   928: iload #5
    //   930: ifeq -> 1137
    //   933: aload_0
    //   934: getfield mCross : Ljava/lang/String;
    //   937: ifnull -> 1137
    //   940: aload_0
    //   941: getfield mFireCross : Ljava/lang/reflect/Method;
    //   944: ifnonnull -> 1046
    //   947: aload_0
    //   948: aload_2
    //   949: invokevirtual getClass : ()Ljava/lang/Class;
    //   952: aload_0
    //   953: getfield mCross : Ljava/lang/String;
    //   956: iconst_0
    //   957: anewarray java/lang/Class
    //   960: invokestatic getMethod : (Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   963: putfield mFireCross : Ljava/lang/reflect/Method;
    //   966: goto -> 1046
    //   969: new java/lang/StringBuilder
    //   972: dup
    //   973: invokespecial <init> : ()V
    //   976: astore #13
    //   978: aload #13
    //   980: aload #12
    //   982: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   985: pop
    //   986: aload #13
    //   988: aload_0
    //   989: getfield mCross : Ljava/lang/String;
    //   992: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   995: pop
    //   996: aload #13
    //   998: aload #10
    //   1000: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1003: pop
    //   1004: aload #13
    //   1006: aload_2
    //   1007: invokevirtual getClass : ()Ljava/lang/Class;
    //   1010: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   1013: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1016: pop
    //   1017: aload #13
    //   1019: aload #9
    //   1021: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1024: pop
    //   1025: aload #13
    //   1027: aload_2
    //   1028: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   1031: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1034: pop
    //   1035: aload #11
    //   1037: aload #13
    //   1039: invokevirtual toString : ()Ljava/lang/String;
    //   1042: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1045: pop
    //   1046: aload_0
    //   1047: getfield mFireCross : Ljava/lang/reflect/Method;
    //   1050: aload_2
    //   1051: iconst_0
    //   1052: anewarray java/lang/Object
    //   1055: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   1058: pop
    //   1059: return
    //   1060: new java/lang/StringBuilder
    //   1063: dup
    //   1064: invokespecial <init> : ()V
    //   1067: astore #12
    //   1069: aload #12
    //   1071: aload #8
    //   1073: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1076: pop
    //   1077: aload #12
    //   1079: aload_0
    //   1080: getfield mCross : Ljava/lang/String;
    //   1083: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1086: pop
    //   1087: aload #12
    //   1089: aload #10
    //   1091: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1094: pop
    //   1095: aload #12
    //   1097: aload_2
    //   1098: invokevirtual getClass : ()Ljava/lang/Class;
    //   1101: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   1104: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1107: pop
    //   1108: aload #12
    //   1110: aload #9
    //   1112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1115: pop
    //   1116: aload #12
    //   1118: aload_2
    //   1119: invokestatic getName : (Landroid/view/View;)Ljava/lang/String;
    //   1122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1125: pop
    //   1126: aload #11
    //   1128: aload #12
    //   1130: invokevirtual toString : ()Ljava/lang/String;
    //   1133: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1136: pop
    //   1137: return
    //   1138: astore #13
    //   1140: goto -> 547
    //   1143: astore #13
    //   1145: goto -> 640
    //   1148: astore #13
    //   1150: goto -> 758
    //   1153: astore #13
    //   1155: goto -> 851
    //   1158: astore #13
    //   1160: goto -> 969
    //   1163: astore #12
    //   1165: goto -> 1060
    // Exception table:
    //   from	to	target	type
    //   525	544	1138	java/lang/NoSuchMethodException
    //   624	637	1143	java/lang/Exception
    //   736	755	1148	java/lang/NoSuchMethodException
    //   835	848	1153	java/lang/Exception
    //   947	966	1158	java/lang/NoSuchMethodException
    //   1046	1059	1163	java/lang/Exception
  }
  
  public void getAttributeNames(HashSet<String> paramHashSet) {}
  
  int getCurveFit() {
    return this.mCurveFit;
  }
  
  public void load(Context paramContext, AttributeSet paramAttributeSet) {
    Loader.read(this, paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.KeyTrigger), paramContext);
  }
  
  public void setValue(String paramString, Object paramObject) {}
  
  private static class Loader {
    private static final int COLLISION = 9;
    
    private static final int CROSS = 4;
    
    private static final int FRAME_POS = 8;
    
    private static final int NEGATIVE_CROSS = 1;
    
    private static final int POSITIVE_CROSS = 2;
    
    private static final int POST_LAYOUT = 10;
    
    private static final int TARGET_ID = 7;
    
    private static final int TRIGGER_ID = 6;
    
    private static final int TRIGGER_RECEIVER = 11;
    
    private static final int TRIGGER_SLACK = 5;
    
    private static SparseIntArray mAttrMap;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      mAttrMap = sparseIntArray;
      sparseIntArray.append(R.styleable.KeyTrigger_framePosition, 8);
      mAttrMap.append(R.styleable.KeyTrigger_onCross, 4);
      mAttrMap.append(R.styleable.KeyTrigger_onNegativeCross, 1);
      mAttrMap.append(R.styleable.KeyTrigger_onPositiveCross, 2);
      mAttrMap.append(R.styleable.KeyTrigger_motionTarget, 7);
      mAttrMap.append(R.styleable.KeyTrigger_triggerId, 6);
      mAttrMap.append(R.styleable.KeyTrigger_triggerSlack, 5);
      mAttrMap.append(R.styleable.KeyTrigger_motion_triggerOnCollision, 9);
      mAttrMap.append(R.styleable.KeyTrigger_motion_postLayoutCollision, 10);
      mAttrMap.append(R.styleable.KeyTrigger_triggerReceiver, 11);
    }
    
    public static void read(KeyTrigger param1KeyTrigger, TypedArray param1TypedArray, Context param1Context) {
      int j = param1TypedArray.getIndexCount();
      for (int i = 0;; i++) {
        if (i < j) {
          StringBuilder stringBuilder;
          String str;
          int k = param1TypedArray.getIndex(i);
          switch (mAttrMap.get(k)) {
            default:
              stringBuilder = new StringBuilder();
              stringBuilder.append(v416f9e89.xbd520268("2764"));
              stringBuilder.append(Integer.toHexString(k));
              stringBuilder.append(v416f9e89.xbd520268("2765"));
              stringBuilder.append(mAttrMap.get(k));
              str = stringBuilder.toString();
              Log.e(v416f9e89.xbd520268("2766"), str);
              i++;
              continue;
            case 11:
              KeyTrigger.access$702(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerReceiver));
            case 10:
              KeyTrigger.access$602(param1KeyTrigger, param1TypedArray.getBoolean(k, param1KeyTrigger.mPostLayout));
              break;
            case 9:
              KeyTrigger.access$502(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerCollisionId));
              break;
            case 8:
              param1KeyTrigger.mFramePosition = param1TypedArray.getInteger(k, param1KeyTrigger.mFramePosition);
              KeyTrigger.access$002(param1KeyTrigger, (param1KeyTrigger.mFramePosition + 0.5F) / 100.0F);
              break;
            case 7:
              if (MotionLayout.IS_IN_EDIT_MODE) {
                param1KeyTrigger.mTargetId = param1TypedArray.getResourceId(k, param1KeyTrigger.mTargetId);
                if (param1KeyTrigger.mTargetId == -1)
                  param1KeyTrigger.mTargetString = param1TypedArray.getString(k); 
                break;
              } 
              if ((param1TypedArray.peekValue(k)).type == 3) {
                param1KeyTrigger.mTargetString = param1TypedArray.getString(k);
                break;
              } 
              param1KeyTrigger.mTargetId = param1TypedArray.getResourceId(k, param1KeyTrigger.mTargetId);
              break;
            case 6:
              KeyTrigger.access$402(param1KeyTrigger, param1TypedArray.getResourceId(k, param1KeyTrigger.mTriggerID));
              break;
            case 5:
              param1KeyTrigger.mTriggerSlack = param1TypedArray.getFloat(k, param1KeyTrigger.mTriggerSlack);
              break;
            case 4:
              KeyTrigger.access$302(param1KeyTrigger, param1TypedArray.getString(k));
              break;
            case 2:
              KeyTrigger.access$202(param1KeyTrigger, param1TypedArray.getString(k));
              break;
            case 1:
              KeyTrigger.access$102(param1KeyTrigger, param1TypedArray.getString(k));
              break;
          } 
        } else {
          break;
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\motion\widget\KeyTrigger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */