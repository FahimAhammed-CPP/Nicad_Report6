package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.motion.utils.CurveFit;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.R;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.HashMap;
import java.util.HashSet;

public class KeyTimeCycle extends Key {
  public static final int KEY_TYPE = 3;
  
  static final String NAME = v416f9e89.xbd520268("2680");
  
  private static final String TAG = v416f9e89.xbd520268("2681");
  
  private float mAlpha = Float.NaN;
  
  private int mCurveFit = -1;
  
  private float mElevation = Float.NaN;
  
  private float mProgress = Float.NaN;
  
  private float mRotation = Float.NaN;
  
  private float mRotationX = Float.NaN;
  
  private float mRotationY = Float.NaN;
  
  private float mScaleX = Float.NaN;
  
  private float mScaleY = Float.NaN;
  
  private String mTransitionEasing;
  
  private float mTransitionPathRotate = Float.NaN;
  
  private float mTranslationX = Float.NaN;
  
  private float mTranslationY = Float.NaN;
  
  private float mTranslationZ = Float.NaN;
  
  private float mWaveOffset = 0.0F;
  
  private CurveFit mWaveOffsetSpline;
  
  private float mWavePeriod = Float.NaN;
  
  private CurveFit mWavePeriodSpline;
  
  private int mWaveShape = 0;
  
  public void addTimeValues(HashMap<String, TimeCycleSplineSet> paramHashMap) {
    for (String str2 : paramHashMap.keySet()) {
      StringBuilder stringBuilder;
      String str1;
      ConstraintAttribute constraintAttribute;
      TimeCycleSplineSet timeCycleSplineSet = paramHashMap.get(str2);
      boolean bool = str2.startsWith(v416f9e89.xbd520268("2682"));
      byte b = 7;
      if (bool) {
        str2 = str2.substring(7);
        constraintAttribute = this.mCustomConstraints.get(str2);
        if (constraintAttribute != null)
          ((TimeCycleSplineSet.CustomSet)timeCycleSplineSet).setPoint(this.mFramePosition, constraintAttribute, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
        continue;
      } 
      constraintAttribute.hashCode();
      switch (constraintAttribute.hashCode()) {
        default:
          b = -1;
          break;
        case 92909918:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2683"))) {
            b = 11;
            break;
          } 
        case 37232917:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2684"))) {
            b = 10;
            break;
          } 
        case -4379043:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2685"))) {
            b = 9;
            break;
          } 
        case -40300674:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2686"))) {
            b = 8;
            break;
          } 
        case -908189617:
        
        case -908189618:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2688"))) {
            b = 6;
            break;
          } 
        case -1001078227:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2689"))) {
            b = 5;
            break;
          } 
        case -1225497655:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2690"))) {
            b = 4;
            break;
          } 
        case -1225497656:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2691"))) {
            b = 3;
            break;
          } 
        case -1225497657:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2692"))) {
            b = 2;
            break;
          } 
        case -1249320805:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2693"))) {
            b = 1;
            break;
          } 
        case -1249320806:
          if (constraintAttribute.equals(v416f9e89.xbd520268("2694"))) {
            b = 0;
            break;
          } 
      } 
      switch (b) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append(v416f9e89.xbd520268("2695"));
          stringBuilder.append((String)constraintAttribute);
          stringBuilder.append(v416f9e89.xbd520268("2696"));
          str1 = stringBuilder.toString();
          Log.e(v416f9e89.xbd520268("2697"), str1);
          continue;
        case 11:
          if (!Float.isNaN(this.mAlpha))
            str1.setPoint(this.mFramePosition, this.mAlpha, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 10:
          if (!Float.isNaN(this.mTransitionPathRotate))
            str1.setPoint(this.mFramePosition, this.mTransitionPathRotate, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 9:
          if (!Float.isNaN(this.mElevation))
            str1.setPoint(this.mFramePosition, this.mElevation, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 8:
          if (!Float.isNaN(this.mRotation))
            str1.setPoint(this.mFramePosition, this.mRotation, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 7:
          if (!Float.isNaN(this.mScaleY))
            str1.setPoint(this.mFramePosition, this.mScaleY, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 6:
          if (!Float.isNaN(this.mScaleX))
            str1.setPoint(this.mFramePosition, this.mScaleX, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 5:
          if (!Float.isNaN(this.mProgress))
            str1.setPoint(this.mFramePosition, this.mProgress, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 4:
          if (!Float.isNaN(this.mTranslationZ))
            str1.setPoint(this.mFramePosition, this.mTranslationZ, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 3:
          if (!Float.isNaN(this.mTranslationY))
            str1.setPoint(this.mFramePosition, this.mTranslationY, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 2:
          if (!Float.isNaN(this.mTranslationX))
            str1.setPoint(this.mFramePosition, this.mTranslationX, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 1:
          if (!Float.isNaN(this.mRotationY))
            str1.setPoint(this.mFramePosition, this.mRotationY, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
          continue;
        case 0:
          break;
      } 
      continue;
      if (!Float.isNaN(this.mRotationX))
        SYNTHETIC_LOCAL_VARIABLE_5.setPoint(this.mFramePosition, this.mRotationX, this.mWavePeriod, this.mWaveShape, this.mWaveOffset); 
    } 
  }
  
  public void addValues(HashMap<String, SplineSet> paramHashMap) {
    throw new IllegalArgumentException(v416f9e89.xbd520268("2698"));
  }
  
  public void getAttributeNames(HashSet<String> paramHashSet) {
    if (!Float.isNaN(this.mAlpha))
      paramHashSet.add(v416f9e89.xbd520268("2699")); 
    if (!Float.isNaN(this.mElevation))
      paramHashSet.add(v416f9e89.xbd520268("2700")); 
    if (!Float.isNaN(this.mRotation))
      paramHashSet.add(v416f9e89.xbd520268("2701")); 
    if (!Float.isNaN(this.mRotationX))
      paramHashSet.add(v416f9e89.xbd520268("2702")); 
    if (!Float.isNaN(this.mRotationY))
      paramHashSet.add(v416f9e89.xbd520268("2703")); 
    if (!Float.isNaN(this.mTranslationX))
      paramHashSet.add(v416f9e89.xbd520268("2704")); 
    if (!Float.isNaN(this.mTranslationY))
      paramHashSet.add(v416f9e89.xbd520268("2705")); 
    if (!Float.isNaN(this.mTranslationZ))
      paramHashSet.add(v416f9e89.xbd520268("2706")); 
    if (!Float.isNaN(this.mTransitionPathRotate))
      paramHashSet.add(v416f9e89.xbd520268("2707")); 
    if (!Float.isNaN(this.mScaleX))
      paramHashSet.add(v416f9e89.xbd520268("2708")); 
    if (!Float.isNaN(this.mScaleY))
      paramHashSet.add(v416f9e89.xbd520268("2709")); 
    if (!Float.isNaN(this.mProgress))
      paramHashSet.add(v416f9e89.xbd520268("2710")); 
    if (this.mCustomConstraints.size() > 0)
      for (String str : this.mCustomConstraints.keySet()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("2711"));
        stringBuilder.append(str);
        paramHashSet.add(stringBuilder.toString());
      }  
  }
  
  int getCurveFit() {
    return this.mCurveFit;
  }
  
  public void load(Context paramContext, AttributeSet paramAttributeSet) {
    Loader.read(this, paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.KeyTimeCycle));
  }
  
  public void setInterpolation(HashMap<String, Integer> paramHashMap) {
    if (this.mCurveFit == -1)
      return; 
    if (!Float.isNaN(this.mAlpha)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2712"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mElevation)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2713"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mRotation)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2714"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mRotationX)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2715"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mRotationY)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2716"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mTranslationX)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2717"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mTranslationY)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2718"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mTranslationZ)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2719"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mTransitionPathRotate)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2720"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mScaleX)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2721"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mScaleX)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2722"), Integer.valueOf(i));
    } 
    if (!Float.isNaN(this.mProgress)) {
      int i = this.mCurveFit;
      paramHashMap.put(v416f9e89.xbd520268("2723"), Integer.valueOf(i));
    } 
    if (this.mCustomConstraints.size() > 0)
      for (String str : this.mCustomConstraints.keySet()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(v416f9e89.xbd520268("2724"));
        stringBuilder.append(str);
        paramHashMap.put(stringBuilder.toString(), Integer.valueOf(this.mCurveFit));
      }  
  }
  
  public void setValue(String paramString, Object paramObject) {
    paramString.hashCode();
    int i = paramString.hashCode();
    byte b = -1;
    switch (i) {
      case 1317633238:
        if (!paramString.equals(v416f9e89.xbd520268("2725")))
          break; 
        b = 13;
        break;
      case 579057826:
        if (!paramString.equals(v416f9e89.xbd520268("2726")))
          break; 
        b = 12;
        break;
      case 92909918:
        if (!paramString.equals(v416f9e89.xbd520268("2727")))
          break; 
        b = 11;
        break;
      case 37232917:
        if (!paramString.equals(v416f9e89.xbd520268("2728")))
          break; 
        b = 10;
        break;
      case -4379043:
        if (!paramString.equals(v416f9e89.xbd520268("2729")))
          break; 
        b = 9;
        break;
      case -40300674:
        if (!paramString.equals(v416f9e89.xbd520268("2730")))
          break; 
        b = 8;
        break;
      case -908189617:
        if (!paramString.equals(v416f9e89.xbd520268("2731")))
          break; 
        b = 7;
        break;
      case -908189618:
        if (!paramString.equals(v416f9e89.xbd520268("2732")))
          break; 
        b = 6;
        break;
      case -1001078227:
        if (!paramString.equals(v416f9e89.xbd520268("2733")))
          break; 
        b = 5;
        break;
      case -1225497656:
        if (!paramString.equals(v416f9e89.xbd520268("2734")))
          break; 
        b = 4;
        break;
      case -1225497657:
        if (!paramString.equals(v416f9e89.xbd520268("2735")))
          break; 
        b = 3;
        break;
      case -1249320805:
        if (!paramString.equals(v416f9e89.xbd520268("2736")))
          break; 
        b = 2;
        break;
      case -1249320806:
        if (!paramString.equals(v416f9e89.xbd520268("2737")))
          break; 
        b = 1;
        break;
      case -1812823328:
        if (!paramString.equals(v416f9e89.xbd520268("2738")))
          break; 
        b = 0;
        break;
    } 
    switch (b) {
      default:
        return;
      case 13:
        this.mTranslationZ = toFloat(paramObject);
        return;
      case 12:
        this.mCurveFit = toInt(paramObject);
        return;
      case 11:
        this.mAlpha = toFloat(paramObject);
        return;
      case 10:
        this.mTransitionPathRotate = toFloat(paramObject);
        return;
      case 9:
        this.mElevation = toFloat(paramObject);
        return;
      case 8:
        this.mRotation = toFloat(paramObject);
        return;
      case 7:
        this.mScaleY = toFloat(paramObject);
        return;
      case 6:
        this.mScaleX = toFloat(paramObject);
        return;
      case 5:
        this.mProgress = toFloat(paramObject);
        return;
      case 4:
        this.mTranslationY = toFloat(paramObject);
        return;
      case 3:
        this.mTranslationX = toFloat(paramObject);
        return;
      case 2:
        this.mRotationY = toFloat(paramObject);
        return;
      case 1:
        this.mRotationX = toFloat(paramObject);
        return;
      case 0:
        break;
    } 
    this.mTransitionEasing = paramObject.toString();
  }
  
  private static class Loader {
    private static final int ANDROID_ALPHA = 1;
    
    private static final int ANDROID_ELEVATION = 2;
    
    private static final int ANDROID_ROTATION = 4;
    
    private static final int ANDROID_ROTATION_X = 5;
    
    private static final int ANDROID_ROTATION_Y = 6;
    
    private static final int ANDROID_SCALE_X = 7;
    
    private static final int ANDROID_SCALE_Y = 14;
    
    private static final int ANDROID_TRANSLATION_X = 15;
    
    private static final int ANDROID_TRANSLATION_Y = 16;
    
    private static final int ANDROID_TRANSLATION_Z = 17;
    
    private static final int CURVE_FIT = 13;
    
    private static final int FRAME_POSITION = 12;
    
    private static final int PROGRESS = 18;
    
    private static final int TARGET_ID = 10;
    
    private static final int TRANSITION_EASING = 9;
    
    private static final int TRANSITION_PATH_ROTATE = 8;
    
    private static final int WAVE_OFFSET = 21;
    
    private static final int WAVE_PERIOD = 20;
    
    private static final int WAVE_SHAPE = 19;
    
    private static SparseIntArray mAttrMap;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      mAttrMap = sparseIntArray;
      sparseIntArray.append(R.styleable.KeyTimeCycle_android_alpha, 1);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_elevation, 2);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_rotation, 4);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_rotationX, 5);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_rotationY, 6);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_scaleX, 7);
      mAttrMap.append(R.styleable.KeyTimeCycle_transitionPathRotate, 8);
      mAttrMap.append(R.styleable.KeyTimeCycle_transitionEasing, 9);
      mAttrMap.append(R.styleable.KeyTimeCycle_motionTarget, 10);
      mAttrMap.append(R.styleable.KeyTimeCycle_framePosition, 12);
      mAttrMap.append(R.styleable.KeyTimeCycle_curveFit, 13);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_scaleY, 14);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_translationX, 15);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_translationY, 16);
      mAttrMap.append(R.styleable.KeyTimeCycle_android_translationZ, 17);
      mAttrMap.append(R.styleable.KeyTimeCycle_motionProgress, 18);
      mAttrMap.append(R.styleable.KeyTimeCycle_wavePeriod, 20);
      mAttrMap.append(R.styleable.KeyTimeCycle_waveOffset, 21);
      mAttrMap.append(R.styleable.KeyTimeCycle_waveShape, 19);
    }
    
    public static void read(KeyTimeCycle param1KeyTimeCycle, TypedArray param1TypedArray) {
      int j = param1TypedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        StringBuilder stringBuilder;
        String str;
        int k = param1TypedArray.getIndex(i);
        switch (mAttrMap.get(k)) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append(v416f9e89.xbd520268("2549"));
            stringBuilder.append(Integer.toHexString(k));
            stringBuilder.append(v416f9e89.xbd520268("2550"));
            stringBuilder.append(mAttrMap.get(k));
            str = stringBuilder.toString();
            Log.e(v416f9e89.xbd520268("2551"), str);
            break;
          case 21:
            if ((param1TypedArray.peekValue(k)).type == 5) {
              KeyTimeCycle.access$602(param1KeyTimeCycle, param1TypedArray.getDimension(k, param1KeyTimeCycle.mWaveOffset));
              break;
            } 
            KeyTimeCycle.access$602(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mWaveOffset));
            break;
          case 20:
            KeyTimeCycle.access$502(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mWavePeriod));
            break;
          case 19:
            KeyTimeCycle.access$402(param1KeyTimeCycle, param1TypedArray.getInt(k, param1KeyTimeCycle.mWaveShape));
            break;
          case 18:
            KeyTimeCycle.access$1602(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mProgress));
            break;
          case 17:
            if (Build.VERSION.SDK_INT >= 21)
              KeyTimeCycle.access$1502(param1KeyTimeCycle, param1TypedArray.getDimension(k, param1KeyTimeCycle.mTranslationZ)); 
            break;
          case 16:
            KeyTimeCycle.access$1402(param1KeyTimeCycle, param1TypedArray.getDimension(k, param1KeyTimeCycle.mTranslationY));
            break;
          case 15:
            KeyTimeCycle.access$1302(param1KeyTimeCycle, param1TypedArray.getDimension(k, param1KeyTimeCycle.mTranslationX));
            break;
          case 14:
            KeyTimeCycle.access$1102(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mScaleY));
            break;
          case 13:
            KeyTimeCycle.access$302(param1KeyTimeCycle, param1TypedArray.getInteger(k, param1KeyTimeCycle.mCurveFit));
            break;
          case 12:
            param1KeyTimeCycle.mFramePosition = param1TypedArray.getInt(k, param1KeyTimeCycle.mFramePosition);
            break;
          case 10:
            if (MotionLayout.IS_IN_EDIT_MODE) {
              param1KeyTimeCycle.mTargetId = param1TypedArray.getResourceId(k, param1KeyTimeCycle.mTargetId);
              if (param1KeyTimeCycle.mTargetId == -1)
                param1KeyTimeCycle.mTargetString = param1TypedArray.getString(k); 
              break;
            } 
            if ((param1TypedArray.peekValue(k)).type == 3) {
              param1KeyTimeCycle.mTargetString = param1TypedArray.getString(k);
              break;
            } 
            param1KeyTimeCycle.mTargetId = param1TypedArray.getResourceId(k, param1KeyTimeCycle.mTargetId);
            break;
          case 9:
            KeyTimeCycle.access$1002(param1KeyTimeCycle, param1TypedArray.getString(k));
            break;
          case 8:
            KeyTimeCycle.access$1202(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mTransitionPathRotate));
            break;
          case 7:
            KeyTimeCycle.access$702(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mScaleX));
            break;
          case 6:
            KeyTimeCycle.access$902(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mRotationY));
            break;
          case 5:
            KeyTimeCycle.access$802(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mRotationX));
            break;
          case 4:
            KeyTimeCycle.access$202(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mRotation));
            break;
          case 2:
            KeyTimeCycle.access$102(param1KeyTimeCycle, param1TypedArray.getDimension(k, param1KeyTimeCycle.mElevation));
            break;
          case 1:
            KeyTimeCycle.access$002(param1KeyTimeCycle, param1TypedArray.getFloat(k, param1KeyTimeCycle.mAlpha));
            break;
        } 
      } 
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\motion\widget\KeyTimeCycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */