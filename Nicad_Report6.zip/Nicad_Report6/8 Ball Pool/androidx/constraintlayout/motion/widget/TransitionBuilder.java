package androidx.constraintlayout.motion.widget;

import androidx.constraintlayout.widget.ConstraintSet;
import h8800e55c.pc41fcc5f.v416f9e89;

public class TransitionBuilder {
  private static final String TAG = v416f9e89.xbd520268("2008");
  
  public static MotionScene.Transition buildTransition(MotionScene paramMotionScene, int paramInt1, int paramInt2, ConstraintSet paramConstraintSet1, int paramInt3, ConstraintSet paramConstraintSet2) {
    MotionScene.Transition transition = new MotionScene.Transition(paramInt1, paramMotionScene, paramInt2, paramInt3);
    updateConstraintSetInMotionScene(paramMotionScene, transition, paramConstraintSet1, paramConstraintSet2);
    return transition;
  }
  
  private static void updateConstraintSetInMotionScene(MotionScene paramMotionScene, MotionScene.Transition paramTransition, ConstraintSet paramConstraintSet1, ConstraintSet paramConstraintSet2) {
    int i = paramTransition.getStartConstraintSetId();
    int j = paramTransition.getEndConstraintSetId();
    paramMotionScene.setConstraintSet(i, paramConstraintSet1);
    paramMotionScene.setConstraintSet(j, paramConstraintSet2);
  }
  
  public static void validate(MotionLayout paramMotionLayout) {
    if (paramMotionLayout.mScene != null) {
      MotionScene motionScene = paramMotionLayout.mScene;
      if (motionScene.validateLayout(paramMotionLayout)) {
        if (motionScene.mCurrentTransition != null && !motionScene.getDefinedTransitions().isEmpty())
          return; 
        throw new RuntimeException(v416f9e89.xbd520268("2009"));
      } 
      throw new RuntimeException(v416f9e89.xbd520268("2010"));
    } 
    throw new RuntimeException(v416f9e89.xbd520268("2011"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\androidx\constraintlayout\motion\widget\TransitionBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */